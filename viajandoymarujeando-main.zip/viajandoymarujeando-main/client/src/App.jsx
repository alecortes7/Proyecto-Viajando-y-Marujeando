import './App.css'
import { ContextProvider } from "./context/ContextProvider";
import 'bootstrap/dist/css/bootstrap.min.css';
import { AppRoutes } from './Routes/AppRoutes';


function App() {


  return (
    <ContextProvider>
      <AppRoutes />
    </ContextProvider>
  )
}

export default App
