/* eslint-disable no-unused-vars */
import { useContext, useState } from 'react'
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom'
import { MainHome } from '../pages/Home/MainHome/MainHome'
import { NavBarUser } from '../components/NavBarUser/NavBarUser'
import { Footer } from '../components/Footer/Footer'
import { ErrorPage } from './../pages/ErrorPage/ErrorPage';
import { BookingParcels } from './../pages/Booking/BookingParcels/BookingParcels';
import {FormRegister} from '../components/FormRegister/FormRegister'
import { AdminUsers } from '../pages/Admin/AdminUsers/AdminUsers'
import { AdminServices } from '../pages/Admin/AdminServices/AdminServices'
import {AdminParcel} from '../pages/Admin/AdminParcel/AdminParcel'
import { AdminBooking } from '../pages/Admin/AdminBooking/AdminBooking'
import { ProfileUser } from '../pages/User/ProfileUser/ProfileUser'
import { FormLogin } from '../components/FormLogin/FormLogin'
import { NuestraHistoria } from '../pages/StaticPages/NuestraHistoria/NuestraHistoria'
import { QueHacer } from '../pages/StaticPages/QueHacer/QueHacer'
import { DeportesAcuaticos } from '../pages/StaticPages/DeportesAcuaticos/DeportesAcuaticos'
import { Gastronomia } from '../pages/StaticPages/Gastronomia/Gastronomia'
import { ServicesPricing } from '../pages/Services/ServicesPricing/ServicesPricing'
import { ModalRegistroOk } from '../components/ModalRegistroOk/ModalRegistroOk'
import { ConfirmRegister } from '../pages/Auth/ConfirmRegister/ConfirmRegister'
import { ResetPassword } from '../pages/Auth/ResetPassword/ResetPassword'
import { BookingDates } from '../pages/Booking/BookingDates/BookingDates'
import { ConfirmResetPassword } from '../pages/Auth/ResetPassword/ConfirmResetPassword'
import { BookingServices } from '../pages/Booking/BookingServices/BookingServices'
import { BookingInfo } from '../pages/Booking/BookingInfo/BookingInfo'
import { CampingContext } from '../context/ContextProvider'
import { FormContact } from '../components/FormContact/FormContact'
import { AdminGraficas } from '../pages/Admin/AdminGraficas/adminGraficas'



export const AppRoutes = () => {
  const [showFormRegister, setShowFormRegister] = useState(false);
  const [showFormLogin, setShowFormLogin] = useState(false);
  const [showRegistroOk, setShowRegistroOk] = useState(false);
  const [showModalContraseña, setShowModalContraseña] = useState(false);
  const [showNewContraseña, setShowNewContraseña] = useState(false);
  const [showReservaOk, setShowReservaOk] = useState(false);
  const {user} = useContext(CampingContext)
  
  //Función para redirigir a home y mostrar modal de registro
  const mostrarModalRegistro = () => {
    setShowFormRegister(true)
    setShowFormLogin(false)
  }
  
  //Función para redirigir a home y mostrar modal de login
  const mostrarModalLogin = () => {
    setShowFormLogin(true)
    setShowFormRegister(false)
  }
  
  //Función para mostrar modal de registro ok
  const mostrarRegistroOk = () => {
    setShowRegistroOk(true);
  }
  
  //Función para mostras modal de reestablecer contraseña
  const mostrarModalContraseña = () => {
    setShowModalContraseña(true);
    setShowFormLogin(false);
  }

  //Función para mostrar modal de contraseña enviada al email
  const modalNewContraseña = () => {
    setShowNewContraseña(true);
  }

  //Funcion para mostrar modal de reserva realizada correctamente
  const mostrarReservaOk = () => {
    setShowReservaOk(true);
  }

  return (
    <BrowserRouter>
      <header>
        <NavBarUser 
          mostrarModalRegistro={mostrarModalRegistro}
          mostrarModalLogin={mostrarModalLogin}
          mostrarRegistroOk={mostrarRegistroOk}
          showRegistroOk={showRegistroOk}
        />
      </header>
   
      <main className='main-ppal'>

      <ResetPassword  
        showModalContraseña={showModalContraseña}
        setShowModalContraseña={setShowModalContraseña}
        modalNewContraseña={modalNewContraseña}
      />
          
      <FormRegister 
        showFormRegister={showFormRegister}
        setShowFormRegister={setShowFormRegister}
        mostrarModalLogin={mostrarModalLogin}
        mostrarRegistroOk={mostrarRegistroOk}
      />
      
      <ModalRegistroOk 
        showRegistroOk={showRegistroOk}
        setShowRegistroOk={setShowRegistroOk}
      
      />
      
      <FormLogin 
        showFormLogin={showFormLogin}
        setShowFormLogin={setShowFormLogin}
        mostrarModalRegistro={mostrarModalRegistro}
        mostrarModalContraseña={mostrarModalContraseña}
      />

      <ConfirmResetPassword 
        showNewContraseña={showNewContraseña}
        setShowNewContraseña={setShowNewContraseña}
      />

        <Routes>

          {/* Validaciones de rutas, solo puede acceder si es administrador */}
          {user?.user_type === 1 && <>
          <Route path='/adminUsers' element={<AdminUsers/>}/>
          <Route path='/adminServices' element={<AdminServices/>}/>
          <Route path='/adminParcel' element={<AdminParcel/>}/>
          <Route path='/adminBooking' element={<AdminBooking/>}/> 
          <Route path='/adminGraficas' element={<AdminGraficas/>}/>             
          </>}
          {/* ------Fin validaciones admin ----------------*/}
          <Route path='/' element={<MainHome 
                                    showFormRegister={showFormRegister}
                                    setShowFormRegister={setShowFormRegister}
                                    showFormLogin={showFormLogin}
                                    setShowFormLogin={setShowFormLogin}
                                    mostrarModalRegistro={mostrarModalRegistro}
                                    mostrarModalLogin={mostrarModalLogin}
                                  />}/>
          {/* Validaciones de rutas, solo si esta logueado y es usuario normal */}
          {user?.user_type === 2 && <>
          <Route path='/bookingParcels' element={<BookingParcels/>}/>
          <Route path='/bookingDates' element={<BookingDates/>}/>
          <Route path='/bookingServices' element={<BookingServices/>}/>
          <Route path='/bookingInfo' element={<BookingInfo 
            mostrarReservaOk={mostrarReservaOk}
            showReservaOk={showReservaOk}
            setShowReservaOk={setShowReservaOk}
          />}/> 
          </>}
          {/* ------Fin validaciones usuarios ----------------*/}

          {/* Se podra acceder solo si esta logueado independientemente del typo de usuario */}
          {(user?.user_type === 1 || user?.user_type === 2) &&  
          <Route path='/profileUser' element={<ProfileUser/>}/> }
          {/* ------------Fin valicación---------------- */}

          <Route path='/nuestraHistoria' element={<NuestraHistoria/>}/>
          <Route path='/deportesAcuaticos' element={<DeportesAcuaticos/>}/>
          <Route path='/queHacer' element={<QueHacer/>}/>
          <Route path='/gastronomia' element={<Gastronomia/>}/>
          <Route path='/servicesPricing' element={<ServicesPricing/>}/>
          <Route path='/confirmRegister' element={<ConfirmRegister />}/>
          <Route path='/formContact' element={<FormContact />}/>
          <Route path='*' element={<ErrorPage />} />
        </Routes>
      </main>
      <footer className='app-footer'>
        <Footer/>
      </footer>
    </BrowserRouter>
  )
}
