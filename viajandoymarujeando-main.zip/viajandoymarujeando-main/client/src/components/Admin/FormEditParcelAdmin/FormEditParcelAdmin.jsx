/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import { useContext, useEffect, useState } from 'react'
import Modal from 'react-bootstrap/Modal';
import { Form } from 'react-bootstrap';
import axios from 'axios';
import { CampingContext } from '../../../context/ContextProvider';


const initialValueParcel = {
  parcel_name: "",
  area: "",
  parcel_price: "",
  parcel_available: "",
  parcel_id: ""
}

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const FormEditParcelAdmin = ({showFormEditParcel, setShowFormEditParcel, parcel, fetchParcels}) => {

  const [editParcel, setEditParcel] = useState(initialValueParcel);
  const { token } = useContext(CampingContext)
  const [inputError, setInputError] = useState({});

  useEffect(() => {
    if(parcel){
      setEditParcel({
        parcel_name: parcel.parcel_name,
        area: parcel.area,
        parcel_price: parcel.parcel_price,
        parcel_available: parcel.parcel_available,
        parcel_id: parcel.parcel_id
      })
    }
  }, [parcel])

  const handleChange = (e) => {
    const {name, value} = e.target;
    
    setEditParcel({...editParcel, [name] : value})
  }

  const onSubmit = async () => {
    try{
      const res = await axios.put(`${apiUrl}admin/adminEditParcel`, editParcel, { headers: { Authorization: `Bearer ${token}` } });
      setShowFormEditParcel(false)
      fetchParcels();
    }catch(err){
      console.log(err); 
      
      if (err.response && err.response.data && Array.isArray(err.response.data)) {
        const inputError = {};
        err.response.data.forEach(error => {
          inputError[error.path] = error.msg;
        })
        setInputError(inputError);
      }
    }
  }

  const handleClose = () => {
    setShowFormEditParcel(false)
    setInputError({});
    setEditParcel(initialValueParcel)
  }

  return (
    <div
      className="modal show"
      style={{ display: 'block', position: 'initial' }}
    >
      <Modal show={showFormEditParcel} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Editar Parcela</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <Form>
          <Form.Group className="mb-3" controlId="formBasicName">
              <Form.Label>Nombre de la parcela</Form.Label>
              <Form.Control
                type="text"
                placeholder="Introduzca el nombre de la parcela"
                name='parcel_name' 
                onChange={handleChange}  
                value={editParcel.parcel_name} 
                isInvalid={!!inputError.parcel_name}          
              />
              {inputError.parcel_name && <p className="text-danger">{inputError.parcel_name}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicArea">
              <Form.Label>Area</Form.Label>
              <Form.Control
                type="number"
                placeholder="Introduzca el area de la parcela"
                name='area' 
                onChange={handleChange}  
                value={editParcel.area}  
                isInvalid={!!inputError.area}          
              />
              {inputError.area && <p className="text-danger">{inputError.area}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicPrice">
              <Form.Label>Precio</Form.Label>
              <Form.Control
                type="number"
                placeholder="Introduzca el precio de la parcela"
                name='parcel_price' 
                onChange={handleChange}  
                value={editParcel.parcel_price}  
                isInvalid={!!inputError.parcel_price}          
              />
              {inputError.parcel_price && <p className="text-danger">{inputError.parcel_price}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicSelect">
              <Form.Label>Estado de la parcela</Form.Label>
              <Form.Control
                as="select"
                name="parcel_available"
                value={editParcel.parcel_available}
                onChange={handleChange}
                isInvalid={!!inputError.parcel_available} 
              >
                <option value={1}>Disponible</option>
                <option value={0}>No Disponible</option>
                {inputError.parcel_available && <p className="text-danger">{inputError.parcel_available}</p>}
              </Form.Control>

            </Form.Group>
          </Form>
        </Modal.Body>

        <Modal.Footer>
        <button className='btn-default' onClick={onSubmit}>Aceptar</button>
        <button className='btn-default' onClick={handleClose}>Cancelar</button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}
