/* eslint-disable react/prop-types */

import axios from 'axios'
import { Form } from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import { useContext, useState } from 'react';
import { CampingContext } from '../../../context/ContextProvider';
import upload from '../../../assets/images/upload.png'

const apiUrl = import.meta.env.VITE_SERVER_URL;


export const FormEditServicesAdmin = ({ showFormEditService, setShowFormEditService, servicio, setServicio, obtenerServicios }) => {
  const [inputError, setInputError] = useState({});
  const [file, setFile] = useState();

  const { token } = useContext(CampingContext)

  const handleChange = (e) => {
    const { name, value } = e.target;
    setServicio({ ...servicio, [name]: value });
  }

  const handleFile = (e) => {
    setFile(e.target.files[0]);
  }

  //Función para cerrar formulario
  const handleClose = () => {
    setShowFormEditService(false);
    setInputError({});
    setServicio({})
    setFile();
  }

  const onSubmit = async () => {
    //Preparación de los datos que se mandan al back
    const newFormData = new FormData();
    newFormData.append("data", JSON.stringify(servicio));
    newFormData.append("file", file);

    //mandar los datos a la base de datos
    try {
      const res = await axios.put(`${apiUrl}admin/editService`, newFormData, { headers: { Authorization: `Bearer ${token}` } });
      if (res.status === 200) {
        console.log('Servicio añadido', res.data);
        // Cerrar el modal si la respuesta es válida
        handleClose();
        setServicio({});
        obtenerServicios(token);
      }
    }
    catch (err) {
      console.log(err);

      if (err.response && err.response.data && Array.isArray(err.response.data)) {
        const inputError = {};
        err.response.data.forEach(error => {
          inputError[error.path] = error.msg;
        })
        setInputError(inputError);
      }
    }
  }

  return (
    <>
      <Modal show={showFormEditService} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Editar Servicio</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="formBasicName">
              <Form.Label>Nombre</Form.Label>
              <Form.Control
                type="text"
                placeholder="Nombre del servicio"
                name='service_name'
                value={servicio.service_name ? servicio.service_name : ""}
                onChange={handleChange}
                isInvalid={!!inputError.service_name}
              />
              {inputError.service_name && <p className="text-danger">{inputError.service_name}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicDescription">
              <Form.Label>Descripción</Form.Label>
              <Form.Control
                as="textarea"
                placeholder="Descripción del servicio"
                name="service_description"
                value={servicio.service_description ? servicio.service_description : ""}
                onChange={handleChange}
                isInvalid={!!inputError.service_description}
                rows={5}
              />
              {inputError.service_description && <p className="text-danger">{inputError.service_description}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicPrice">
              <Form.Label>Precio</Form.Label>
              <Form.Control
                type="number"
                placeholder="Precio del servicio"
                name='service_price'
                value={servicio.service_price ? servicio.service_price : ""}
                onChange={handleChange}
                isInvalid={!!inputError.service_price}
              />
              {inputError.service_price && <p className="text-danger">{inputError.service_price}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicSelect">
              <Form.Label>Estado del Servicio</Form.Label>
              <Form.Control
                as="select"
                name="service_is_deleted"
                value={servicio.service_is_deleted}
                onChange={handleChange}
              >
                <option value={0}>Activo</option>
                <option value={1}>Desactivado</option>
              </Form.Control>
            </Form.Group>
            <div className='text-center'>
              <Form.Group className="mb-3">
                <Form.Label htmlFor='image' >Imagen del servicio<img src={upload} alt="" /></Form.Label>
                <Form.Control
                  type="file"
                  onChange={handleFile}
                  hidden
                  id='image'
                />
              </Form.Group>
            </div>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <div className="d-flex gap-3">
            <button className='btn-default' onClick={onSubmit}>Aceptar</button>
            <button className='btn-default' onClick={handleClose}>Cancelar</button>
          </div>
        </Modal.Footer>
      </Modal>
    </>
  )
}

