
import { Row, Col } from 'react-bootstrap';
import './footer.css'

export const Footer = () => {
  return (
    <div className='main-footer'>
      <Row className='footer-row'>
        <Col className='footer-col' md={4}>
          <h5 className='ocultar'>Contacto</h5>
          <div>
            <p><span className='ocultar'>Email:</span> viajandoymarujeando@gmail.com</p>
            <p>Teléfono: +123 456 789</p>
          </div>
        </Col>
        <Col className='footer-col' md={4}>
          <h5 className='ocultar'>Síguenos</h5>
          <ul className="list-unstyled footer-icons">
            <li>
              <a href="https://wa.me/623023901" className="icon-link" target="_blank" rel="noopener noreferrer">
                <i className="bi bi-whatsapp fs-3"></i>
              </a>
            </li>
            <li>
              <a href="https://www.instagram.com/viajandoymarujeando/" className="icon-link" target="_blank" rel="noopener noreferrer">
                <i className="bi bi-instagram fs-3"></i>
              </a>
            </li>
            <li>
              <a href="https://www.facebook.com" className="icon-link" target="_blank" rel="noopener noreferrer">
                <i className="bi bi-facebook fs-3"></i>
              </a>
            </li>
            <li>
              <a href="https://www.tiktok.com" className="icon-link" target="_blank" rel="noopener noreferrer">
                <i className="bi bi-tiktok fs-3"></i>
              </a>
            </li>
          </ul>
        </Col>
      </Row>
      <Row className="mt-4">
        <Col className="text-center">
          <p>&copy; 2024 Viajando y Marujeando. Todos los derechos reservados.</p>
        </Col>
      </Row>
    </div>
  )
}
