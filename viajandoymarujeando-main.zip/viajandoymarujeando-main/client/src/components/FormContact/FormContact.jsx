import { useState } from 'react'
import { Form } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './formContact.css'

const initialValue = {
  name: "",
  lastname: "",
  phone: "",
  email: "",
  comment: "",
};

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const FormContact = () => {
  const [datos, setDatos] = useState(initialValue);
  const [errorMensaje, setErrorMensaje] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const {name, value} = e.target;
    setDatos({...datos, [name]:value});
    setErrorMensaje("");
  }

  const onSubmit = async (e) => {
    e.preventDefault();

    const {name, lastname, phone, email, comment} = datos;

    if(!name || !lastname || !phone || !email || !comment){
      setErrorMensaje("Todos los campos deben estar rellenos");
      return;
    }

    try{
      const res = await axios.post(`${apiUrl}sendContact`, {
        name,
        lastname,
        phone,
        email,
        comment
      });
      setDatos(initialValue);
      navigate('/');
    }
    catch(error){
      console.log(error)
    }
  }

  const handleClose = (e) => {
    e.preventDefault();
    setDatos(initialValue);
    navigate('/');
  }

  return (
    <div className='d-flex flex-column align-items-center p-3 bg-image-cf2'>
      <Form className='static-div-contact'>
        <h1 className='text-center'>Formulario de contacto</h1>
        <Form.Group className='mb-3' controlId="formBasicName">
          <Form.Label>Nombre</Form.Label>
          <Form.Control
              type="text"
              placeholder="Tu nombre"
              name='name'
              value={datos.name}
              onChange={handleChange}
            />
        </Form.Group>
        <Form.Group className='mb-3' controlId="formBasicLastname">
          <Form.Label>Apellido</Form.Label>
          <Form.Control
              type="text"
              placeholder="Tu apellido"
              name='lastname'
              value={datos.lastname}
              onChange={handleChange}
            />
        </Form.Group>
        <Form.Group className='mb-3' controlId="formBasicPhone">
          <Form.Label>Teléfono</Form.Label>
          <Form.Control
              type="text"
              placeholder="Teléfono"
              name='phone'
              value={datos.phone}
              onChange={handleChange}
            />
        </Form.Group>
        <Form.Group className='mb-3' controlId="formBasicEmail">
          <Form.Label>Email</Form.Label>
          <Form.Control
              type="email"
              placeholder="Email"
              name='email'
              value={datos.email}
              onChange={handleChange}
            />
        </Form.Group>
        <Form.Group className='mb-3' controlId="formBasicComment">
          <Form.Label>Comentario</Form.Label>
          <Form.Control
              as='textarea'
              placeholder="Comentario"
              name='comment'
              value={datos.comment}
              onChange={handleChange}
              rows={3}
            />
        </Form.Group>
        {errorMensaje && 
          <p style={{color:"red"}}>{errorMensaje}</p>
        }
        <div className='d-flex gap-4'>
              <button className='btn-default' onClick={onSubmit}>Enviar</button>
              <button className='btn-default' onClick={handleClose}>Cancelar</button>
        </div>
      </Form>
    </div>
  )
}
