/* eslint-disable react/prop-types */

import axios from 'axios'
import { Form } from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import '../FormRegister/formRegisterLogin.css'
import { useContext, useEffect, useState } from 'react';
import upload from '../../assets/images/upload.png'
import { CampingContext } from '../../context/ContextProvider';

const initialValue = {
  user_name: "",
  lastname: "",
  phone: "",
  dni: "",
  address: "",
  province: "",
  city: "",
  country: "",
}

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const FormEditUser = ({showFormEditUser, setShowFormEditUser}) => {

  const [editUser, setEditUser] = useState(initialValue);
  const [inputError, setInputError] = useState({});
  const [file, setFile] = useState();
  
  const {user, token, setUser} = useContext(CampingContext);

  useEffect(()=>{
    if(user){
      setEditUser({
        user_name: user.user_name,
        lastname: user.lastname,
        phone: user.phone,
        dni: user.dni,
        address: user.address,
        province: user.province,
        city: user.city,
        country: user.country,
      })
    }
},[user])

  const handleChange = (e) => {
    const {name, value} = e.target;
    setEditUser({...editUser, [name]:value});
  }

  const handleFile = (e) => {
    setFile(e.target.files[0]);
  }
  
  const onSubmit = async () => {

    try{

      //Preparación de los datos que se mandan al back
      const newFormData = new FormData();
      newFormData.append("data", JSON.stringify(editUser));
      newFormData.append("file", file);


      //Mandar dastos preparados al back
      const res = await axios.put(`${apiUrl}users/editUser/${user.user_id}`, newFormData, {headers:{Authorization: `Bearer ${token}`}});
      if (res.status === 200) {
        // Cerrar el modal si la respuesta es válida
        handleClose(); 
        setEditUser(initialValue);
        const res2 = await axios.get(`${apiUrl}users/getOneUser/`, {headers:{Authorization: `Bearer ${token}`}})

        setUser(res2.data)
      }
      
    }
    catch(err){
      console.log(err);
      
      if(err.response && err.response.data && Array.isArray(err.response.data)){
        const inputError = {};
        err.response.data.forEach(error => {
          inputError[error.path] = error.msg;
        })
        setInputError(inputError);
      }  
    }
  }

  //Función para cerrar formulario
  const handleClose = () => {
    setShowFormEditUser(false);
    setInputError({});
    setEditUser(initialValue)
  }


  return (
    <>
    <Modal show={showFormEditUser} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Editar perfil</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
        <div className="row">
          <div className="col-sm-12 col-md-12 col-xl-6">
            <Form.Group className="mb-3" controlId="formBasicName">
              <Form.Label>Nombre</Form.Label>
              <Form.Control
                type="text"
                placeholder="Introduzca name"
                name='user_name'
                value={editUser.user_name}
                onChange={handleChange}
                isInvalid={!!inputError.user_name}
              />
              {inputError.user_name && <p className="text-danger">{inputError.user_name}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicLastName">
              <Form.Label>Apellidos</Form.Label>
              <Form.Control
                type="text"
                placeholder="Introduzca lastname"
                name='lastname'
                value={editUser.lastname}
                onChange={handleChange}
                isInvalid={!!inputError.lastname}
              />
              {inputError.lastname && <p className="text-danger">{inputError.lastname}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicPhone">
              <Form.Label>Teléfono</Form.Label>
              <Form.Control
                type="text"
                placeholder="Introduzca phone"
                name='phone'
                value={editUser.phone}
                onChange={handleChange}
                isInvalid={!!inputError.phone}
              />
              {inputError.phone && <p className="text-danger">{inputError.phone}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicDNI">
              <Form.Label>DNI</Form.Label>
              <Form.Control
                type="text"
                placeholder="Introduzca DNI"
                name='dni'
                value={editUser.dni}
                onChange={handleChange}
                isInvalid={!!inputError.dni}
              />
              {inputError.dni && <p className="text-danger">{inputError.dni}</p>}
            </Form.Group>
          </div>
          <div className="col-sm-12 col-md-12 col-xl-6">
            <Form.Group className="mb-3" controlId="formBasicAddress">
            <Form.Label>Dirección</Form.Label>
            <Form.Control
                type="text"
                placeholder="Tu dirección"
                name='address'
                value={editUser.address ? editUser.address : ""}
                onChange={handleChange}
                isInvalid={!!inputError.address}
              />
              {inputError.address && <p className="text-danger">{inputError.address}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicProvince">
            <Form.Label>Provincia</Form.Label>
            <Form.Control
                type="text"
                placeholder="Tu provincia"
                name='province'
                value={editUser.province ? editUser.province : ""}
                onChange={handleChange}
                isInvalid={!!inputError.province}
              />
              {inputError.province && <p className="text-danger">{inputError.province}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicCity">
            <Form.Label>Ciudad</Form.Label>
            <Form.Control
                type="text"
                placeholder="Tu ciudad"
                name='city'
                value={editUser.city ? editUser.city : ""}
                onChange={handleChange}
                isInvalid={!!inputError.city}
              />
              {inputError.city && <p className="text-danger">{inputError.city}</p>}
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicCountry">
            <Form.Label>País</Form.Label>
            <Form.Control
                type="text"
                placeholder="Tu país"
                name='country'
                value={editUser.country ? editUser.country : "" }
                onChange={handleChange}
                isInvalid={!!inputError.country}
              />
              {inputError.country && <p className="text-danger">{inputError.country}</p>}
            </Form.Group>
          </div>
        </div>
        </Form>
      </Modal.Body>

      <div className='text-center'>
        <Form.Group className="mb-3">
        <Form.Label htmlFor='image' >Foto de perfil<img src={upload} alt="" /></Form.Label>
        <Form.Control
          type="file"
          onChange={handleFile}
          hidden
          id='image'
        />
            </Form.Group>
      </div>

      <Modal.Footer className='d-flex justify-content-center gap-2'>
        <button className='btn-default' onClick={onSubmit}>Aceptar</button>
        <button className='btn-default' onClick={handleClose}>Cancelar</button>
      </Modal.Footer>
    </Modal>
  </>
  )
}
