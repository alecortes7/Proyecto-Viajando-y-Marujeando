/* eslint-disable react/prop-types */

import { useContext, useState } from 'react'
import { Form } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom'
import Modal from 'react-bootstrap/Modal';
import { CampingContext } from '../../context/ContextProvider';
import '../FormRegister/formRegisterLogin.css'
import axios from 'axios';

const initialValue = {
  email: "",
  password: ""
};

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const FormLogin = ({showFormLogin, setShowFormLogin, mostrarModalRegistro, mostrarModalContraseña}) => {
  
  const [login, setLogin] = useState(initialValue);
  const [msg, setMsg] = useState("");
  const {setUser, setToken} = useContext(CampingContext);

  const navigate = useNavigate();

  //Función para cerrar formulario
  const handleClose = () => {
    setShowFormLogin(false);
    setMsg('');
  }

  const handleChange = (e) => {
    const {name, value} = e.target;
    setLogin({...login, [name]: value})
  };

  const onSubmit = async () => {
    //mandar datos a db para comprobar que coinciden email y password
    try{
      const res = await axios.post(`${apiUrl}users/login`, login);
      const tokenBack = res.data;
      setToken(tokenBack);
      const res2 = await axios.get(`${apiUrl}users/getOneUser`, {headers:{Authorization: `Bearer ${tokenBack}`}})
      const user = res2.data;
      localStorage.setItem("token", tokenBack)
      setUser(user);
      if(user.user_type === 1) {navigate('/adminUsers')};
      if(user.user_type === 2){navigate('/')};
      handleClose();
    }
    catch(err){
      setMsg(err.response.data);
      console.log(err);  
    }
  }

  return (
    <>
      <Modal show={showFormLogin} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Login</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Email</Form.Label>
            <Form.Control 
              type="email" 
              placeholder="Introduzca email" 
              name='email'
              value={login.email}
              onChange={handleChange}
            />
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicPassword">
            <Form.Label>Contraseña</Form.Label>
            <Form.Control 
              type="password" 
              placeholder="Introduzca contraseña" 
              name='password'
              value={login.password}
              onChange={handleChange}
            />
          </Form.Group>
          </Form>
        </Modal.Body>
          <p className='text-center' style={{color:"red"}}>{msg}</p>
        <Modal.Footer className='d-flex flex-column gap-2'>
        <div className='d-flex gap-3'>
            <button className='btn-default' onClick={onSubmit}>Aceptar</button>
            <button className='btn-default' onClick={handleClose}>Cancelar</button>
        </div>
          <p>¿No estás registrado? Regístrate <span className='aqui' onClick={mostrarModalRegistro}>aquí</span></p>
          <p><span className='aqui' onClick={mostrarModalContraseña}>No recuerdo mi contraseña </span></p>
        </Modal.Footer>
      </Modal>
    </>
  )
}
