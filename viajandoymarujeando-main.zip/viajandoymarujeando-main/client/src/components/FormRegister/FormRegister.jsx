/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import axios from 'axios'
import { Form } from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import './formRegisterLogin.css'
import { useState } from 'react';

const initialValue = {
  user_name: "",
  lastname: "",
  phone: "",
  dni: "",
  email: "",
  password: "",
  password2: ""
}

const apiUrl = import.meta.env.VITE_SERVER_URL;


export const FormRegister = ({showFormRegister, setShowFormRegister, mostrarModalLogin, mostrarRegistroOk}) => {
  const [register, setRegister] = useState(initialValue);
  const [inputError, setInputError] = useState({});

  const handleChange = (e) => {
    const {name, value} = e.target;
    setRegister({...register, [name]:value});
  }
  
  const onSubmit = async () => {
    //Comprobar que todos los campos estén completos
    const {user_name, lastname, phone, dni, email, password, password2} = register;

    //mandar los datos a la base de datos
    try{
      const res = await axios.post(`${apiUrl}users/registerUser`, register);
      if (res.status === 200) {
        console.log('Usuario registrado', res.data);
        //hacer modal de registro correcto
        mostrarRegistroOk();
        // Cerrar el modal si la respuesta es válida
        handleClose(); 
        setRegister(initialValue);
      }
    }
    catch(err){
      console.log(err)

      if(err.response && err.response.data && Array.isArray(err.response.data)){
        const inputError = {};
        err.response.data.forEach(error => {
          inputError[error.path] = error.msg;
        })
        setInputError(inputError);
      }
    }
  }

  //Función para cerrar formulario
  const handleClose = () => {
    setShowFormRegister(false);
    setInputError({});
    setRegister(initialValue)
  }

 
  return (
    <>
    <Modal show={showFormRegister} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Registro</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
        <Form.Group className="mb-3" controlId="formBasicName">
          <Form.Label>Nombre</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Tu nombre" 
            name='user_name'
            value={register.user_name}
            onChange={handleChange}
            isInvalid={!!inputError.user_name}
          />
          {inputError.user_name && <p className="text-danger">{inputError.user_name}</p>}
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicLastName">
          <Form.Label>Apellidos</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Tu apellido" 
            name='lastname'
            value={register.lastname}
            onChange={handleChange}
            isInvalid={!!inputError.lastname}
          />
          {inputError.lastname && <p className="text-danger">{inputError.lastname}</p>}
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicPhone">
          <Form.Label>Teléfono</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Tu teléfono" 
            name='phone'
            value={register.phone}
            onChange={handleChange}
            isInvalid={!!inputError.phone}
          />
          {inputError.phone && <p className="text-danger">{inputError.phone}</p>}
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicDNI">
          <Form.Label>DNI</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Tu dni" 
            name='dni'
            value={register.dni}
            onChange={handleChange}
            isInvalid={!!inputError.dni}
          />
          {inputError.dni && <p className="text-danger">{inputError.dni}</p>}
        </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Email</Form.Label>
          <Form.Control 
            type="email" 
            placeholder="Tu email" 
            name='email'
            value={register.email}
            onChange={handleChange}
            isInvalid={!!inputError.email}
          />
          {inputError.email && <p className="text-danger">{inputError.email}</p>}
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Contraseña</Form.Label>
          <Form.Control 
            type="password" 
            placeholder="Tu contraseña" 
            name='password'
            value={register.password}
            onChange={handleChange}
            isInvalid={!!inputError.password}
          />
          {inputError.password && <p className="text-danger">{inputError.password}</p>}
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicPassword2">
          <Form.Label>Repite Contraseña</Form.Label>
          <Form.Control 
            type="password" 
            placeholder="Repite contraseña" 
            name='password2'
            value={register.password2}
            onChange={handleChange}
            isInvalid={!!inputError.password2}
          />
          {inputError.password2 && <p className="text-danger">{inputError.password2}</p>}
        </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer className='d-flex flex-column gap-2'>
      <div className='d-flex gap-4'>
            <button className='btn-default' onClick={onSubmit}>Aceptar</button>
            <button className='btn-default' onClick={handleClose}>Cancelar</button>
      </div>
        <p>¿Ya estás registrado? Entra <span className='aqui' onClick={mostrarModalLogin}>aquí</span></p>
      </Modal.Footer>
    </Modal>
  </>
  )
}

