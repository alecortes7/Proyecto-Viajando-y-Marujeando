/* eslint-disable react/prop-types */

import { Modal } from 'react-bootstrap'
import axios from "axios";
import { useContext } from 'react';

const apiUrl = import.meta.env.VITE_SERVER_URL;
import { CampingContext } from './../../context/ContextProvider';

export const ModalConfirDelService = ({showConfirDelService, setShowConfirDelService, idServicio, obtenerServicios}) => {

  const { token } = useContext(CampingContext);


  //Función para cerrar modal confirmacion borrar servicio
  const handleClose = () => {
    setShowConfirDelService(false);
  }

  const delServicio = async () => {

    try {
      let res = await axios
        .get(`${apiUrl}admin/delService/${idServicio}`, {
          headers: { Authorization: `Bearer ${token}` }
        })
      //Ejecutar funcion para refrescar lista de servicios depues de eliminar
      obtenerServicios(token);
      handleClose();

    } catch (error) {
      console.log(error)
    }
  }


  return (
    <>
    <Modal show={showConfirDelService} onHide={handleClose}>
    <Modal.Header closeButton>
      <Modal.Title>Confirmación eliminar servicio</Modal.Title>
    </Modal.Header>
    <Modal.Body>
    <p className="text-bg-danger">¿Estas seguro de eliminar el servicio?</p>
    </Modal.Body>
    <Modal.Footer>
      <button className='btn-default' onClick={handleClose}>No</button>
      <button className='btn-default' onClick={()=> {delServicio()}}>Si</button>
    </Modal.Footer>
  </Modal>
    </>
  )
}
