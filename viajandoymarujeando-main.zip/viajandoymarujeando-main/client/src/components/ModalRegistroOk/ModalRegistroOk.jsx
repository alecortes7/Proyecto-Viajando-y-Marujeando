/* eslint-disable react/prop-types */

import { Button, Modal } from 'react-bootstrap'

export const ModalRegistroOk = ({showRegistroOk, setShowRegistroOk}) => {

  const handleClose = () => {
    setShowRegistroOk(false);
  }

  return (
    <>
    <Modal show={showRegistroOk} onHide={handleClose}>
    <Modal.Header closeButton>
      <Modal.Title>Registrado correctamente</Modal.Title>
    </Modal.Header>
    <Modal.Body>
    <p className="text-success">Le llegará un email para validar su registro</p>
    </Modal.Body>
    <Modal.Footer>
      <Button variant="secondary" onClick={handleClose} className='btn-default'>
        Cerrar
      </Button>
    </Modal.Footer>
  </Modal>
    </>
  )
}
