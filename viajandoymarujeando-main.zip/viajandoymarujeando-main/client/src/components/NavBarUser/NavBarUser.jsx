/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */

import './NavBarUser.css'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link, useNavigate } from 'react-router-dom'
import logo from '../../assets/images/logo.png'
import { useContext, useState } from 'react';
import { CampingContext } from './../../context/ContextProvider';
import foto from '../../assets/images/perfilDefault.png'
let url_base = import.meta.env.VITE_SERVER_URL;


export const NavBarUser = ({ mostrarModalRegistro, mostrarModalLogin }) => {

  const [expanded, setExpanded] = useState(false);
  const { user, token, setUser, setToken } = useContext(CampingContext);
  const navigate = useNavigate();

   //Cerrar el menu al ahcer click en un enlace
  const handleNavClick = () => {
    setExpanded(false); 
  };

  const cerrarSesionUsuario = () => {
    localStorage.removeItem("token");
    setUser();
    setToken();
    navigate('/');
  }

  return (
    <Navbar expanded={expanded} onToggle={() => setExpanded(!expanded)} expand="lg" className="nav-user">
      <Container fluid>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <div className='mostrar'>

          <img src={logo} alt="Una tabla con una autocaravana pintada" />

        </div>
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mx-auto d-flex flex-column w-100">
            <div className='grid'>
              <div className="nav-logo d-flex mx-auto oculto">
                <img className='oculto' src={logo} alt="Una tabla con una autocaravana pintada" />
              </div>
              <div className="botones">
                <div className="d-flex gap-3">
                  {!user ?
                    <>
                      <button onClick={mostrarModalLogin} className='btn-default'>Entrar</button>
                      <button onClick={mostrarModalRegistro} className='btn-default'>Registro</button>
                    </>
                    :
                    <>
                      <div className='foto-perfil'>
                        <img src={user.image ? `${url_base}images/users/${user.image}` : foto}
                          onClick={() => { navigate('/profileUser') }}
                          alt="Perfil de usuario" />
                      </div>
                      <button onClick={cerrarSesionUsuario} className='btn-default'>Salir</button>
                    </>
                  }
                </div>
              </div>
            </div>
            <div className='d-flex'>
              <div className="d-flex justify-content-center w-100 gap-2">
                {/* --------------NAVEGACIÓN DE USUARIO------------------- */}
                <div className='navegacion-user'>
                  {user?.user_type !== 1 && <>
                  <Nav.Link onClick={handleNavClick} as={Link} to='/'>Inicio</Nav.Link>
                  <NavDropdown title="Información" id="basic-nav-dropdown">
                    <NavDropdown.Item onClick={handleNavClick} as={Link} to='/nuestraHistoria'>Nuestra Historia</NavDropdown.Item>
                    <NavDropdown.Item onClick={handleNavClick} as={Link} to='/queHacer'>
                      Que hacer
                    </NavDropdown.Item>
                    <NavDropdown.Item onClick={handleNavClick} as={Link} to='/deportesAcuaticos'>Deportes acuaticos</NavDropdown.Item>
                    <NavDropdown.Item onClick={handleNavClick} as={Link} to='/gastronomia'>Gastronomia</NavDropdown.Item>
                  </NavDropdown>
                  <Nav.Link onClick={handleNavClick} as={Link} to='/servicesPricing'>Tarifas</Nav.Link>
                  <Nav.Link onClick={handleNavClick} as={Link} to='/formContact'>Contacto</Nav.Link>
                  </>}
                
                {/* -------------FIN NAVEGACIÓN DE USUARIO------------ */}

                {/* -----------SOLO SE MUESTRA SI EL USUARIO ESTA LOGUEADO Y NO ES ADMINISTRADOR */}
                {user?.user_type === 2 && 
                  <Nav.Link onClick={handleNavClick} as={Link} to='/bookingDates'>Reservar</Nav.Link>
                }
                {/* -----------------------------FIN------------------------------------------------ */}
                <div className='user-movil'>
                {!user ? <>
                  <Nav.Link onClick={mostrarModalLogin}>Login</Nav.Link>
                  <Nav.Link onClick={mostrarModalRegistro}>Registro</Nav.Link>
                </>
                :
                <>
                  {user?.user_type === 2 && 
                    <> 
                      <Nav.Link onClick={handleNavClick} as={Link} to='/profileUser'>Perfil</Nav.Link>
                      <Nav.Link onClick={cerrarSesionUsuario}>Salir</Nav.Link>
                    </>}
                </>
                }
                </div>
                </div>

                {/*---------------------- NAVEGACIÓN DEL ADMINISTRADOR---------------- */}
                <div className='navegacion-admin'>
                  {user?.user_type === 1 && <>
                    <Nav.Link onClick={handleNavClick} as={Link} to='/adminUsers'> Clientes</Nav.Link>
                    <Nav.Link onClick={handleNavClick} as={Link} to='/adminServices'>Servicios</Nav.Link>
                    <Nav.Link onClick={handleNavClick} as={Link} to='/adminParcel'>Parcelas</Nav.Link>
                    <Nav.Link onClick={handleNavClick} as={Link} to='/adminBooking'>Reservas</Nav.Link>
                    <Nav.Link onClick={handleNavClick} as={Link} to='/adminGraficas'>Gráficas</Nav.Link>
                    <div className='user-movil'>
                      <Nav.Link onClick={handleNavClick} as={Link} to='/profileUser'>Perfil</Nav.Link>
                      <Nav.Link onClick={cerrarSesionUsuario}>Salir</Nav.Link>
                    </div>
                  </>}
                </div>
                {/*---------------------- ----------FIN ------------------------- */}

              </div>
            </div>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}
