/* eslint-disable react/prop-types */

import axios from 'axios';
import { createContext, useEffect, useState } from 'react'

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const CampingContext = createContext()

export const ContextProvider = ({children}) => {
  const [user, setUser] = useState();
  const [adminUsers, setAdminUsers] = useState();
  const [token, setToken] = useState();



  useEffect(()=>{
    const fetchUser = async (token) => {
      try{
        const res = await axios.get(`${apiUrl}users/getOneUser`, {headers:{Authorization: `Bearer ${token}`}});
        setUser(res.data);
        setToken(token);
      }
      catch(err){
        console.log(err);
      }
    }

    const tokenLocalStorage = localStorage.getItem("token");

    if(tokenLocalStorage){
      fetchUser(tokenLocalStorage)
    }
  },[])
  
  return (
    <CampingContext.Provider value={{user, setUser, token, setToken, adminUsers, setAdminUsers}}>
    {children}
  </CampingContext.Provider>
  )
}
