import { Table } from "react-bootstrap";
import "../adminPanel.css";
import { useContext, useEffect, useState } from "react";
import axios from "axios";
import { CampingContext } from "../../../context/ContextProvider";
import iconDel from '../../../assets/images/papelera.png'

export const AdminBooking = () => {
  const [listaReservas, setListaReservas] = useState();
  const apiUrl = import.meta.env.VITE_SERVER_URL;

  const { token } = useContext(CampingContext)

  const getUserData = async () => {
    try {
      let res = await axios.get(`${apiUrl}admin/adminBooking`, {headers:{Authorization: `Bearer ${token}`}});
      res.data.sort((a, b) => b.booking_id - a.booking_id);
      setListaReservas(res.data);

    } catch (error) {
      console.log(error)
    }
  }

  useEffect(() => {
    getUserData();

  // eslint-disable-next-line react-hooks/exhaustive-deps

  }, [])


  const delBooking = async (id) => {

    try {
      let res = await axios
      .get(`${apiUrl}admin/delBooking/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
        //Ejecutar funcion para refrescar lista de servicios depues de eliminar
        getUserData();
      
    } catch (error) {
      console.log(error)
    }
  }

    //Paginado
    const itemsPerPage = 15;
    const [currentPage, setCurrentPage] = useState(1);
  
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = listaReservas?.slice(indexOfFirstItem, indexOfLastItem);
    const totalPages = Math.ceil(listaReservas?.length / itemsPerPage);
  
    // Funciones para cambiar de página
    const nextPage = () => {
      if (currentPage < totalPages) {
        setCurrentPage(currentPage + 1);
      }
    };
  
    const prevPage = () => {
      if (currentPage > 1) {
        setCurrentPage(currentPage - 1);
      }
    };
  
    // fin codigo paginado


  return (
    <div className="container-fluid imagen-fondo">
      <section>
        <h2 className="my-4">Lista de reservas</h2>
        <div className="table-responsive">
          <Table striped bordered hover>
            <thead>
              <tr>
                <th className='text-center'>Nº reserva</th>
                <th className='text-center'>Nombre cliente</th>
                <th className='text-center'>Parcela</th>
                <th className='text-center'>Entrada</th>
                <th className='text-center'>Salida</th>
                <th className='text-center'>Servicios contratados</th>
                <th className='text-center'>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {currentItems?.map((reserva) => {
                return (
                  <tr key={reserva.booking_id}>
                    <td className='text-center'>{reserva.booking_id}</td>
                    <td className='text-center'>{reserva.user_name}</td>
                    <td className='text-center'>{reserva.parcel_name}</td>
                    <td className='text-center'>{reserva.date_start}</td>
                    <td className='text-center'>{reserva.date_end}</td>
                    <td className='text-center'>{reserva.service_names ? reserva.service_names : "Sin servicios extras" }</td>
                    <td>
                  <div className="d-flex justify-content-center gap-4">
                    <img className="icons-df" onClick={()=> {delBooking(reserva.booking_id)} } src={iconDel} alt="papelera para borrar" />
                  </div>
                </td>
                  </tr>
                )
              })}
            </tbody>
          </Table>
          <div className="menu-paginacion">
            <button onClick={prevPage} disabled={currentPage === 1} className="btn-default">Anterior</button>
            <span>Página {currentPage} de {totalPages}</span>
            <button onClick={nextPage} disabled={currentPage === totalPages} className="btn-default">Siguiente</button>
          </div>
        </div>
      </section>
    </div>
  )
}
