/* eslint-disable no-unused-vars */
import { CampingContext } from '../../../context/ContextProvider';
import '../adminPanel.css'
import './graficas.css'
import React, { PureComponent, useContext, useEffect, useState } from 'react';
import { PieChart, Pie, Sector, Cell, ResponsiveContainer } from 'recharts';
import axios from 'axios';

const apiUrl = import.meta.env.VITE_SERVER_URL;



const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];





export const AdminGraficas = () => {

  const [parcelasMasReservadas, setParcelasMasReservadas] = useState([])
  const [serviciosMasReservados, setServiciosMasReservados] = useState([])
  const [ciudadesMasRepetidas, setCiudadesMasRepetidas] = useState([])
  const [mesMasReservado, setMesMasReservado] = useState([])
  const { token } = useContext(CampingContext)



  useEffect(() => {
    //Funciones para pedir datos al back
    const obtenerParcelMasReservadas = async (token) => {
      try {
        let res = await axios.get(`${apiUrl}admin/getParcelReserved`, {
          headers: { Authorization: `Bearer ${token}` },
        })

        setParcelasMasReservadas(res.data)

      } catch (error) {
        console.log(error)
      }
    }

    const obtenerServiciosMasContratados = async (token) => {
      try {
        let res = await axios.get(`${apiUrl}admin/getServicesReserved`, {
          headers: { Authorization: `Bearer ${token}` },
        })

        setServiciosMasReservados(res.data)

      } catch (error) {
        console.log(error)
      }
    }

    const obtenerCiudadesMasRepetidas = async (token) => {
      try {
        let res = await axios.get(`${apiUrl}admin/getCityReserved`, {
          headers: { Authorization: `Bearer ${token}` },
        })

   
        setCiudadesMasRepetidas(res.data)

      } catch (error) {
        console.log(error)
      }
    }

    const obtenerMesMasReservado = async (token) => {
      try {
        let res = await axios.get(`${apiUrl}admin/getMonthReserved`, {
          headers: { Authorization: `Bearer ${token}` },
        })

   
        setMesMasReservado(res.data)

      } catch (error) {
        console.log(error)
      }
    }

    obtenerParcelMasReservadas(token);
    obtenerServiciosMasContratados(token);
    obtenerCiudadesMasRepetidas(token);
    obtenerMesMasReservado(token);

  }, [])

  //Función para grafica
  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };


  return (
    <div className='container-fluid imagen-fondo'>
      <h2 className='mb-3 text-center'>Estadísticas del Área</h2>
      <section className='grid'>
        {/* -----------------------GRAFICA PARCELAS RESERVADAS------------------------------ */}
        <article className='grafica d-flex justify-content-center flex-column align-items-center grafica-uno'>
          <h3 className='title'>Parcelas más reservadas</h3>
          <ResponsiveContainer width="90%" height="80%">
            <PieChart width={400} height={400}>
              <Pie
                data={parcelasMasReservadas}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={renderCustomizedLabel}
                outerRadius={150}
                fill="#8884d8"
                dataKey="total_reservations"
              >
                {parcelasMasReservadas.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className='text-center d-flex justify-content-center leyenda'>
              <span className='primera'>{parcelasMasReservadas[0]?.parcel_name}</span>
              <span className='segunda'>{parcelasMasReservadas[1]?.parcel_name}</span>
              <span className='tercera'>{parcelasMasReservadas[2]?.parcel_name}</span>
              <span className='cuarta'>{parcelasMasReservadas[3]?.parcel_name}</span>
          </div>
        </article>
        {/* -----------------------GRAFICA SERVICIOS RESERVADAS------------------------------ */}
        <article className='grafica d-flex justify-content-center flex-column align-items-center grafica-dos'>
          <h3 className='title'>Servicios más reservados</h3>
          <ResponsiveContainer width="90%" height="80%">
            <PieChart width={400} height={400}>
              <Pie
                data={serviciosMasReservados}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={renderCustomizedLabel}
                outerRadius={150}
                fill="#8884d8"
                dataKey="total_contracted"
              >
                {serviciosMasReservados.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className='d-flex justify-content-center leyenda'>

            <div className='primera text-center'>{serviciosMasReservados[0]?.service_name}</div>
            <div className='segunda text-center'>{serviciosMasReservados[1]?.service_name}</div>

            <div className='tercera text-center'>{serviciosMasReservados[2]?.service_name}</div>
            <div className='cuarta text-center'>{serviciosMasReservados[3]?.service_name}</div>
          </div>
        </article>
         {/* -----------------------GRAFICA CIUDADES DE LOS USUARIOS------------------------------ */}
         <article className='grafica d-flex justify-content-center flex-column align-items-center grafica-uno'>
          <h3 className='title'>Ciudades que más nos visitan</h3>
          <ResponsiveContainer width="90%" height="80%">
            <PieChart width={400} height={400}>
              <Pie
                data={ciudadesMasRepetidas}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={renderCustomizedLabel}
                outerRadius={150}
                fill="#8884d8"
                dataKey="total_reservations"
              >
                {ciudadesMasRepetidas.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className='d-flex justify-content-center leyenda'>

            <div className='primera text-center'>{ciudadesMasRepetidas[0]?.city}</div>
            <div className='segunda text-center'>{ciudadesMasRepetidas[1]?.city}</div>

            <div className='tercera text-center'>{ciudadesMasRepetidas[2]?.city}</div>
            <div className='cuarta text-center'>{ciudadesMasRepetidas[3]?.city}</div>
          </div>
        </article>
                {/* -----------------------GRAFICA MES MAS RESERVADO------------------------------ */}
                <article className='grafica d-flex justify-content-center flex-column align-items-center grafica-dos'>
          <h3 className='title'>Meses con más reservas</h3>
          <ResponsiveContainer width="90%" height="80%">
            <PieChart width={400} height={400}>
              <Pie
                data={mesMasReservado}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={renderCustomizedLabel}
                outerRadius={150}
                fill="#8884d8"
                dataKey="total_reservations"
              >
                {mesMasReservado.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className='d-flex justify-content-center leyenda'>

            <div className='primera text-center'>{mesMasReservado[0]?.month_name}</div>
            <div className='segunda text-center'>{mesMasReservado[1]?.month_name}</div>

            <div className='tercera text-center'>{mesMasReservado[2]?.month_name}</div>
            <div className='cuarta text-center'>{mesMasReservado[3]?.month_name}</div>
          </div>
        </article>

      </section>

    </div>
  )
}
