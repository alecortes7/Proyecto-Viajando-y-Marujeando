/* eslint-disable no-unused-vars */
import { Table } from "react-bootstrap";
import "../adminPanel.css";
import { useEffect, useState } from "react";
import axios from "axios";
import { FormEditParcelAdmin } from "../../../components/Admin/FormEditParcelAdmin/FormEditParcelAdmin";
import edit from '../../../assets/images/editar.png'

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const AdminParcel = () => {

  const [parcels, setParcels] = useState([]);
  const [showFormEditParcel, setShowFormEditParcel] = useState(false)
  const [selectedParcel, setSelectedParcel] = useState(null);


  //Paginado
  const itemsPerPage = 15;
  const [currentPage, setCurrentPage] = useState(1);

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = parcels?.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(parcels.length / itemsPerPage);

  // Funciones para cambiar de página
  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  // fin codigo paginado


  const fetchParcels = async () => {
    try {
      const res = await axios.get(`${apiUrl}admin/allAdminParcels`);
      
      setParcels(res.data.parcels); 
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {

    fetchParcels();
  }, []);

  const handleEditParcel = (parcel) => {
    setSelectedParcel(parcel); // Asigna la parcela seleccionada
    setShowFormEditParcel(true); // Muestra el formulario de edición
  };

  return (
    <div className="container-fluid imagen-fondo">
      <section>
        <h2>Lista de Parcelas</h2>
        <div className="table-responsive mt-3">
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Area</th>
                <th>Precio</th>
                <th>Disponibilidad</th>
                <th>Editar</th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((parcel, index) => (
                <tr key={parcel.parcel_id}>
                  <td>{parcel.parcel_name}</td>
                  <td>{parcel.area}</td>
                  <td>{parcel.parcel_price}</td>
                  <td>{parcel.parcel_available ? "Disponible" : "No disponible"}</td>



                  <td>
                    <img onClick={()=>{
                      setSelectedParcel(parcel);
                      setShowFormEditParcel(true)
                    }} className="icons-df" src={edit}/>
                  </td>

                </tr>
              ))}
            </tbody>
          </Table>
          <div className="menu-paginacion">
            <button onClick={prevPage} disabled={currentPage === 1} className="btn-default">Anterior</button>
            <span>Página {currentPage} de {totalPages}</span>
            <button onClick={nextPage} disabled={currentPage === totalPages} className="btn-default">Siguiente</button>
          </div>
        </div>
      </section>
      < FormEditParcelAdmin 
        parcel={selectedParcel}
        showFormEditParcel={showFormEditParcel}
        setShowFormEditParcel={setShowFormEditParcel}
        fetchParcels={fetchParcels}
      />
    </div>
  )
}
