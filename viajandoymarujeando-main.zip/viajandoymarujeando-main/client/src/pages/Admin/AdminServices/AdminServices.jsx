/* eslint-disable no-unused-vars */
import React, { useContext, useEffect, useState } from "react";
import Table from 'react-bootstrap/Table';
import "bootstrap/dist/css/bootstrap.min.css";
import "../adminPanel.css";
import iconMas from '../../../assets/images/mas.png';
import { FormAddService } from "../../../components/Admin/FormAddService/FormAddService";
import { CampingContext } from "../../../context/ContextProvider";
import axios from "axios";
import iconEdit from '../../../assets/images/editar.png'
import iconDel from '../../../assets/images/papelera.png'
import { FormEditServicesAdmin } from "../../../components/Admin/FormEditServicesAdmin/FormEditServicesAdmin";

import noImage from '../../../assets/images/No_Image_Available.jpg'
import { ModalConfirDelService } from "../../../components/ModalConfirDelService/ModalConfirDelService";

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const AdminServices = () => {
  const [listaServicios, setListaServicios] = useState([]);
  const [servicio, setServicio] = useState({});
  const [showFormAddService, setShowFormAddService] = useState(false);
  const [showConfirDelService, setShowConfirDelService] = useState(false);
  const [showFormEditService, setShowFormEditService] = useState(false);
  const [idServicio, setIdServicio] = useState();

  const { token } = useContext(CampingContext);

  const obtenerServicios = async (token) => {
    let res = await axios
      .get(`${apiUrl}admin/getAllServices`, {
        headers: { Authorization: `Bearer ${token}` },
      })
    setListaServicios(res.data)
  }

  //Funcion para mostrar modal confirmar eliminación
  const confirmarEliminación = (id) => {
    setShowConfirDelService(true);
    setIdServicio(id)
  }

  useEffect(() => {

    obtenerServicios(token);

  }, [])


  const mostrarModalAddService = () => {
    setShowFormAddService(true);
  }


  const editServicio = (data) => {
    setShowFormEditService(true);
    setServicio(data);
  }


  const delServicio = async (id) => {

    try {
      let res = await axios
        .get(`${apiUrl}admin/delService/${id}`, {
          headers: { Authorization: `Bearer ${token}` }
        })
      //Ejecutar funcion para refrescar lista de servicios depues de eliminar
      obtenerServicios(token);

    } catch (error) {
      console.log(error)
    }
  }

  //Paginado
  const itemsPerPage = 6;
  const [currentPage, setCurrentPage] = useState(1);

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = listaServicios?.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(listaServicios?.length / itemsPerPage);

  // Funciones para cambiar de página
  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  // fin codigo paginado



  return (
    <>

      <div className="container-fluid imagen-fondo">
        <section>
          <img className="icono-añadir" onClick={mostrarModalAddService} src={iconMas} alt="Mas para añadir servicio" />
          <h2 className="my-4">Lista de servicios</h2>
          <div className="table-responsive">
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>Imagen</th>
                  <th>Nombre</th>
                  <th>Descripción</th>
                  <th>Precio</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {currentItems?.map((serv) => {
                  return (
                    <tr key={serv.service_id}>
                      <td><img className="foto-servicio" src={serv?.service_image ? `${apiUrl}images/services/${serv.service_image}` : noImage} alt="descripcion del servicio" /></td>
                      <td>{serv.service_name}</td>
                      <td>{serv.service_description}</td>
                      <td>{serv.service_price}</td>
                      <td>
                        <div className="d-flex justify-content-center gap-4">
                          <img className="icons-df" onClick={() => { editServicio(serv) }} src={iconEdit} alt="Lapiz para editar" />
                          <img className="icons-df" onClick={() => { confirmarEliminación(serv.service_id) }} src={iconDel} alt="papelera para borrar" />
                        </div>
                      </td>
                    </tr>
                  )
                })}

              </tbody>
            </Table>
            <div className="menu-paginacion">
              <button onClick={prevPage} disabled={currentPage === 1} className="btn-default">Anterior</button>
              <span>Página {currentPage} de {totalPages}</span>
              <button onClick={nextPage} disabled={currentPage === totalPages} className="btn-default">Siguiente</button>
            </div>
          </div>
        </section>
      </div>
      <FormAddService showFormAddService={showFormAddService} setShowFormAddService={setShowFormAddService} obtenerServicios={obtenerServicios} />
      <FormEditServicesAdmin showFormEditService={showFormEditService} setShowFormEditService={setShowFormEditService} servicio={servicio} setServicio={setServicio} obtenerServicios={obtenerServicios} />
      <ModalConfirDelService showConfirDelService={showConfirDelService} setShowConfirDelService={setShowConfirDelService} idServicio={idServicio} obtenerServicios={obtenerServicios}/>
    </>
  );
};
