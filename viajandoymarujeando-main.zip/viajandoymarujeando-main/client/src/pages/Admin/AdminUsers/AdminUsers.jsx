/* eslint-disable no-unused-vars */
import React, { useContext, useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Table from "react-bootstrap/Table";
import "../adminPanel.css";
import axios from "axios";
import { CampingContext } from "../../../context/ContextProvider";

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  const {token} = useContext(CampingContext)


  //Función para obtener la lista de usuarios
  const ObtenerUsuarios = async (token) => {
    try {
      let res = await axios
      .get(`${apiUrl}admin/adminAllUsers`, {
        headers: { Authorization: `Bearer ${token}` },
      })

      setUsers(res.data.users);
      
    } catch (error) {
      console.log(error)
    }
  }

  useEffect(() => {
    //Llamada a la función para obtener usuarios
    ObtenerUsuarios(token);

  }, [token]);

  const cambiarEstado = (userId, enabled_status) => {
    const token = localStorage.getItem("token");
    if(enabled_status != 3){
      axios
      .put(
        `${apiUrl}admin/deshabilitarUser/${userId}`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      )
      .then((res) => {
        //Llamada a la función para obtener usuarios
        ObtenerUsuarios(token);
      })
      .catch((err) => {
        console.log(err);
      });
    }else{
      axios
      .put(
        `${apiUrl}admin/habilitarUser/${userId}`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      )
      .then((res) => {
        //Llamada a la función para obtener usuarios
        ObtenerUsuarios(token);
      })
      .catch((err) => {
        console.log(err);
      });
    }
  };

    //Paginado
    const itemsPerPage = 15;
    const [currentPage, setCurrentPage] = useState(1);
  
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = users?.slice(indexOfFirstItem, indexOfLastItem);
    const totalPages = Math.ceil(users?.length / itemsPerPage);
  
    // Funciones para cambiar de página
    const nextPage = () => {
      if (currentPage < totalPages) {
        setCurrentPage(currentPage + 1);
      }
    };
  
    const prevPage = () => {
      if (currentPage > 1) {
        setCurrentPage(currentPage - 1);
      }
    };
  
    // fin codigo paginado

  return (
    <div className="container-fluid imagen-fondo">
      <section>
      <h2 className="mt-2">Lista de clientes</h2>
        <div className="table-responsive mt-3">
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Dni</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((user, index) => (
                <tr key={user.user_id}>
                  <td>{user.user_name} {user.lastname}</td>
                  <td>{user.email}</td>
                  <td>{user.phone}</td>
                  <td>{user.dni}</td>
                  <td>
                    <button
                      className="btn-default"
                      onClick={() => cambiarEstado(user.user_id, user.enabled_status)}
                    >
                      {user.enabled_status === 3 ? "Habilitar" : "Deshabilitar"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
          <div className="menu-paginacion">
            <button onClick={prevPage} disabled={currentPage === 1} className="btn-default">Anterior</button>
            <span>Página {currentPage} de {totalPages}</span>
            <button onClick={nextPage} disabled={currentPage === totalPages} className="btn-default">Siguiente</button>
          </div>
        </div>
      </section>
    </div>
  );
};
