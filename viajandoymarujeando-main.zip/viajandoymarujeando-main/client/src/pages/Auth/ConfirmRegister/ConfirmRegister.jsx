import axios from 'axios';
import { useEffect } from 'react'
import { useSearchParams } from 'react-router-dom';
import './confirmRegister.css'

const apiUrl = import.meta.env.VITE_SERVER_URL;


export const ConfirmRegister = () => {
  const [serchParams] = useSearchParams();
  const token = serchParams.get('token');

 useEffect(()=>{
  if(token){
    axios.put(`${apiUrl}users/confirmRegister`, null, {headers:{Authorization: `Bearer ${token}`}})
  }
 },[token])
  
  return (
    <div className='container-conf bg-image-cf'>
      <div className='div-config'>
        <h2 className='text-center'>Registro confirmado correctamente</h2>
        <a href="/">Vuelve al inicio</a>
      </div>
    </div>
  )
}
