/* eslint-disable react/prop-types */

import { Button, Modal } from 'react-bootstrap'

export const ConfirmResetPassword = ({ showNewContraseña, setShowNewContraseña}) => {

  const handleClose = () => {
    setShowNewContraseña(false);
  }
  return (
    <>
    <Modal show={showNewContraseña} onHide={handleClose}>
    <Modal.Header closeButton>
      <Modal.Title>Contraseña restablecida</Modal.Title>
    </Modal.Header>
    <Modal.Body>
    <p className="text-success">Le llegará un email con su nueva contraseña</p>
    </Modal.Body>
    <Modal.Footer>
      <Button variant="secondary" onClick={handleClose} className='btn-default'>
        Cerrar
      </Button>
    </Modal.Footer>
  </Modal>
    </>
  )
}
