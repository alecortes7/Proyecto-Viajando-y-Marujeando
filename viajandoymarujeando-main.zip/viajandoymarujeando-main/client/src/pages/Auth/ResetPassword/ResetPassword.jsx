/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */

import axios from 'axios';
import { useState } from 'react'
import { Button, Form, Modal } from 'react-bootstrap'

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const ResetPassword = ({showModalContraseña, setShowModalContraseña, modalNewContraseña}) => {
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');

  const onSubmit = async () => {
    try{
      const res = await axios.post(`${apiUrl}users/resetPassword`, {email})
      if(res.status === 200){
        setShowModalContraseña(false)
        modalNewContraseña();
      }
    }
    catch(error){
      setMsg("El email no está registrado")
    }
  }
   
  const handleClose = () => {
    setShowModalContraseña(false);
  }

  return (
    <>
      <Modal show={showModalContraseña} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Reestablece contraseña</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Email</Form.Label>
            <Form.Control 
              type="email" 
              placeholder="Introduzca email" 
              name='email'
              value={email}
              onChange={(e)=> setEmail(e.target.value)}
            />
          </Form.Group>

          </Form>
        </Modal.Body>
        <Modal.Footer>
          <button onClick={onSubmit} className='btn-default'>Aceptar</button>
          <button onClick={handleClose} className='btn-default'>Cancelar</button>
          <p>Al aceptar se le enviará a su email la nueva contraseña</p>
          {msg && <p className='text-danger'>{msg}</p>}
        </Modal.Footer>
      </Modal>
    </>
  )
}
