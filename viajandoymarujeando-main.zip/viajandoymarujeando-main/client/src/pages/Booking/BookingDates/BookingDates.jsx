import { useState } from 'react'
import { DayPicker } from 'react-day-picker';
import { useNavigate } from 'react-router-dom';
import 'react-day-picker/dist/style.css';
import './BookingDates.css'

export const BookingDates = () => {
  const currentDate = new Date();
  const navigate = useNavigate();
  const [startDate, setStartDate] = useState();
  const [endDate, setEndDate] = useState(null);
  const [msg, setMsg] = useState('');
  const [errorCalendar, setErrorCalendar] = useState(null);

  const handleStartSelect = (date) => {
    if (date) {
      if (endDate && date >= endDate) {
        setMsg('La fecha de inicio no puede ser igual a la fecha de fin.');
        setErrorCalendar('start');
      }else{
        setStartDate(date);
        if (endDate && date > endDate) {
          setEndDate(null);
        }
        setMsg('');
        setErrorCalendar(null);
      }
    } else {
      setStartDate(null);
      setEndDate(null);
      setMsg('');
      setErrorCalendar(null);
    }
  }

  const handleEndSelect = (date) => {
    if(startDate && date <= startDate){
      setMsg('La fecha de fin no puede ser igual a la fecha de inicio.')
      setErrorCalendar('end');
    }else{
      setEndDate(date)
      setMsg('')
      setErrorCalendar(null);
    }
  }

  const handleNextPage = () => {
    if (startDate && endDate) {
      navigate('/bookingParcels', { state: { startDate, endDate } });
    } else {
      setMsg('Por favor, selecciona fecha de inicio y fecha de fin.');
    }
  }

  return (
    <div className="calendar-container">
      <h2>Selecciona el rango de fechas</h2>
      <div className="calendar-row">
        
        {/* Calendario para seleccionar la fecha de inicio */}
        <div className="calendar-box">
          <h4>Fecha de Inicio:</h4>
          <DayPicker 
            mode="single"
            selected={startDate}
            onSelect={handleStartSelect}
            disabled={{ 
              before: currentDate,
              after: endDate || undefined
            }}
            classNames={{
              selected: 'selected',
              range: 'range',
            }}
          />
          {startDate && <p>Fecha de inicio seleccionada: {startDate.toLocaleDateString()}</p>}
          {errorCalendar === 'start' && <p className='err-date'>{msg}</p>}
        </div>

        {/* Calendario para seleccionar la fecha de fin */}
        <div className="calendar-box">
          <h4>Fecha de Fin:</h4>
          <DayPicker 
            mode="single"
            selected={endDate}
            onSelect={handleEndSelect}
            disabled={{ before: startDate || currentDate }}
            classNames={{
              selected: 'selected',
              range: 'range',
            }}
          />
          {endDate && <p>Fecha de fin seleccionada: {endDate.toLocaleDateString()}</p>}
          {errorCalendar === 'end' && <p className='err-date'>{msg}</p>}
        </div>
      </div>
      <button className='btn-default' onClick={handleNextPage}>Siguiente</button>
      {msg && <p style={{color: 'red'}}>{msg}</p>}
    </div>
  )
}
