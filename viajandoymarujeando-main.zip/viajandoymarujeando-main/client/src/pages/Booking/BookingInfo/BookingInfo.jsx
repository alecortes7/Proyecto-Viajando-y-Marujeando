/* eslint-disable react/prop-types */
import { Col, Container, Row } from 'react-bootstrap'
import './bookingInfo.css'
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useContext, useEffect, useState } from 'react';
import { ModalReservaOk } from '../ModalReservaOk/ModalReservaOk';
import { CampingContext } from '../../../context/ContextProvider';

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const BookingInfo = ({mostrarReservaOk, showReservaOk, setShowReservaOk}) => {
  const [serviciosContratados, setServiciosContratados] = useState([]);
  const location = useLocation();
  const navigate = useNavigate();
  const { parcela, precioFinal, services, formattedDateStart, formattedDateEnd, contador } = location.state || {};
  
  const {user} = useContext(CampingContext);

  const filtrarServiciosContratados = () => {
    
    const serviciosFiltrados = [];

    for (let i = 0; i < contador.length; i++) {
      if(contador[i] > 0){
        serviciosFiltrados.push({
          datosServicio: services[i],
          cantidadServicio: contador[i]
        });
      }
    }
    setServiciosContratados(serviciosFiltrados);
  }

  useEffect(() => {
    filtrarServiciosContratados();
  }, [services, contador]) 

  const handlePrevPage = () => {
    navigate(-1); // Navega a la página anterior
  };

  const handleCancel = () => {
    navigate('/'); // Navega al home
  };

  const handleConfirm = async() => {
    const bookingSave = {
      user_id: user.user_id,
      parcel_id: parcela.id, 
      date_start: formattedDateStart, 
      date_end: formattedDateEnd,
      total_price: precioFinal,
      services: serviciosContratados
    }; 

    // Confirma los datos haciendo insert en la db y abre modal
    try{
      const res = await axios.post(`${apiUrl}reservas/saveBooking`, bookingSave);
      if(res.status === 200){
        //modal de reserva confirmada
        mostrarReservaOk();
      }
    }
    catch(err){
      console.log(err);    
    }
  };
  
  return (
    <Container fluid className="static-container3 bg-image-sp3 mx-0 d-flex flex-column justify-content-center">
    <h2 className="text-center mb-4">Resumen de su reserva</h2>
    <Row className='row-info'>
      <Col md={6} className='d-flex flex-column justify-align-justify-content-evenly gap-4'>
        
        <div className="static-div3">
          <h4>Reserva confirmada:</h4>
          <ul>
                <li>Parcela: {parcela.info}</li>
                <li>Check in: {formattedDateStart}</li>
                <li>Check out: {formattedDateEnd}</li>
                <li>Precio total: {precioFinal} €</li>
          </ul>
        </div>
      </Col>
      <Col md={6} className='d-flex flex-column justify-align-justify-content-evenly gap-4 py-4'>
        <div className="static-div3">
        <h4>Servicios contratados:</h4>
          <br />
          <ul>
            {serviciosContratados?.map((serv, index) => {
              return(
                <li key={index}>
                  {serv.datosServicio.service_name}: {' '}

                  {serv.datosServicio.service_name !== 'Luz en parcela' && 
                    serv.datosServicio.service_name !== 'jacuzzi' &&
                    serv.datosServicio.service_name !== 'Sombra en parcela' ?
                    serv.cantidadServicio : null}

                  {serv.datosServicio.service_name === 'Persona extra (+3 años)' ? ' personas' : ''}

                  {serv.datosServicio.service_name === 'Luz en parcela' || 
                    serv.datosServicio.service_name === 'jacuzzi' || 
                    serv.datosServicio.service_name === 'Sombra en parcela' 
                    ? ' Si' : ''}

                  {serv.datosServicio.service_name !== 'Luz en parcela' &&
                    serv.datosServicio.service_name !== 'jacuzzi' &&
                    serv.datosServicio.service_name !== 'Sombra en parcela' &&
                    serv.datosServicio.service_name !== 'Persona extra (+3 años)' ? ' unidad/es' : ''}
                </li>   
              )
            })
            }
          </ul>
        </div>
      </Col>
    </Row>
    <Row>
      <div className='btn-div'>
          <button className='btn-default' onClick={handlePrevPage}>Atrás</button>
          <button className='btn-default' onClick={handleCancel}>Cancelar</button>
          <button className='btn-default' onClick={handleConfirm}>Confirmar</button>
        </div>
    </Row>
    <ModalReservaOk 
      showReservaOk={showReservaOk}
      setShowReservaOk={setShowReservaOk}
    />
  </Container>
  )
}
