import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from 'react-router-dom';
import foto from "../../../../src/assets/images/mapa-parcelas.png";
import axios from 'axios';
import './BookingParcels.css'

const apiUrl = import.meta.env.VITE_SERVER_URL;


// Algoritmo para verificar si un punto está dentro de un polígono

const colorReserve = "#fe3d3d";
const colorFree = "#2cde3b";

const isPointInPolygon = (point, polygon) => {
  const [x, y] = point;
  let inside = false;

  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i][0],
      yi = polygon[i][1];
    const xj = polygon[j][0],
      yj = polygon[j][1];

    const intersect =
      yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }

  return inside;
};

const parcelasData = [
  {
    id: 1 - 1,
    vertices: [
      [12, 201],
      [65, 202],
      [66, 224],
      [12, 224],
    ],
    reserved: false,
    info: "Sector 1",
  }
];

export const BookingParcels = () => {
  const canvasRef = useRef(null);
  const [selectedParcela, setSelectedParcela] = useState(null);
  const [parcelas, setParcelas] = useState([]);
  const [prueba, setPrueba] = useState();
  const [prueba2, setPrueba2] = useState();
  const location = useLocation();
  const navigate = useNavigate();
  const { startDate, endDate } = location.state || {};
  const [errorMessage, setErrorMessage] = useState("");

  // Pasar las fechas a objeto date
  const startDateObj = new Date(startDate);
  const endDateObj = new Date(endDate);

  // Sumar un día a cada fecha
  startDateObj.setDate(startDateObj.getDate() + 1);
  endDateObj.setDate(endDateObj.getDate() + 1);

  // Formatear las fechas a YYYY-MM-DD
  const formattedDateStart = startDateObj.toISOString().split('T')[0];
  const formattedDateEnd = endDateObj.toISOString().split('T')[0];
  

  // Transforma la respuesta del back al formato que espera el canvas
  const transformarDatos = (parcelasLibres, parcelasOcupadas) => {
    // Transforma cada objeto de la respuesta del back al formato esperado
    const transformarParcela = (parcela, reserved) => {
      
      const vertices = parcela.coordinates
        .split(',')
        .map(Number)
        .reduce((acc, val, i, arr) => {
          if (i % 2 === 0) {
            acc.push([arr[i], arr[i + 1]]);
          }
          return acc;
        }, []);
  
      return {
        id: parcela.parcel_id,
        vertices,
        reserved,
        info: parcela.parcel_name,
        parcel_price: parcela.parcel_price,
      };
    };
  
    // Transformar parcelas libres (reserved: false)
    const parcelasLibresTransformadas = parcelasLibres.map((parcela) =>
      transformarParcela(parcela, false)
    );
  
    // Transformar parcelas ocupadas (reserved: true)
    const parcelasOcupadasTransformadas = parcelasOcupadas.map((parcela) =>
      transformarParcela(parcela, true)
    );
  
    // Combinar ambas listas
    return [...parcelasLibresTransformadas, ...parcelasOcupadasTransformadas];
  };

  // Llamar al back para obtener las parcelas disponibles y las ocupadas
  const obtenerParcelasDisponibles = async () => {
      try {
          const response = await axios.post(`${apiUrl}reservas/dispParcel`, { formattedDateStart, formattedDateEnd});

          const { parcelasLibres, parcelasOcupadas } = response.data;

          const parcelasTransformadas = transformarDatos(parcelasLibres, parcelasOcupadas);
          setParcelas(parcelasTransformadas);
          
      } catch (error) {
          console.error('Error al obtener las parcelas disponibles:', error);
      }
  };

  useEffect(() => {
    obtenerParcelasDisponibles(); // Llama a la función para obtener parcelas
  }, [formattedDateStart, formattedDateEnd]);

  // Cargar el canva con los datos de la DB
  useEffect(() => {
    setParcelas(parcelas); 
  }, []);

  // Renderiza la imagen y los polígonos en el canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    const image = new Image();
    
    image.src = foto; // URL de  a imagen de 500x500px

    image.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height); // Limpiar canvas
      ctx.drawImage(image, 0, 0, 700, 394); // Dibujar la imagen

      // Dibujar los polígonos
      parcelas.forEach((sector) => {
        ctx.beginPath();
        const [firstVertex, ...restVertices] = sector.vertices;
        ctx.moveTo(firstVertex[0], firstVertex[1]);

        restVertices.forEach(([x, y]) => {
          ctx.lineTo(x, y);
        });

        ctx.closePath();
        ctx.fillStyle = sector.reserved ? colorReserve : colorFree;
        ctx.fill();
        ctx.strokeStyle = "black";
        ctx.stroke();
      });
    };
  }, [parcelas]);

  // Detecta clic y determina si está dentro de un polígono
  const handleClick = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const clickedParcela = parcelas.find((parcela) =>
      isPointInPolygon([x, y], parcela.vertices)
    );

    if (clickedParcela) {
      setSelectedParcela(clickedParcela);
      
      if (clickedParcela.reserved) {
        setErrorMessage("Esta parcela ya está reservada.");
      }else{
        setErrorMessage("");
        navigate('/bookingServices', {
          state: {
            parcela: clickedParcela,
            startDate,
            endDate,
            formattedDateStart,
            formattedDateEnd
          },
        });
      }
    }
  };

  const handlePrevPage = () => {
    navigate(-1); // Navega a la página anterior
  };

  const handleSelectChange = (e) => {
    const selectedId = parseInt(e.target.value, 10);
    const selected = parcelas.find((parcel) => parcel.id === selectedId); 
    
    if (selected) {
      setSelectedParcela(selected);
      navigate('/bookingServices', {
        state: {
          parcela: selected,
          startDate,
          endDate,
          formattedDateStart,
          formattedDateEnd,
        },
      });
    }
  };
  

  return (
    <div className="ppal-app p-5 parcels-container" style={{ padding: "100px" }}>
      <div className="parcels-row canvas">
        <h3>Selecciona una parcela</h3>
        <p style={{textAlign:'center'}}>Fecha de Entrada: {formattedDateStart && formattedDateStart} - Fecha de Salida: {formattedDateEnd && formattedDateEnd}</p>
          <canvas
            ref={canvasRef}
            width={700}
            height={394}
            onMouseDown={(e) => {
              setPrueba(e.clientX);
              setPrueba2(e.clientY);
            }}
            onClick={handleClick}
            style={{ border: "1px solid black" }}
          />
      </div>
      {errorMessage && (
      <div className="parcels-row">
        <div>
          <p style={{color: 'red', fontWeight: 'bold'}}>La parcela {selectedParcela.info} ya está reservada.</p>
        </div>
      </div>
      )}

      <div className="mobile-selector">
        <img src="/Booking/parcelasmovil.png" alt="" className="parcelas-movil" />
      </div>

      <div className="mobile-selector">
        <h3>Selecciona una parcela</h3>
        <p>*Solo se mostrarán las parcelas disponibles en la fecha seleccionada</p>
        <select onChange={handleSelectChange}>
          {parcelas.map((parcel) => (
            <option key={parcel.id} value={parcel.id}>
              {parcel.info}
            </option>
          ))}
        </select>
      </div>

      <div className="static-div-parcel">
        <button className='btn-default' onClick={handlePrevPage}>Atrás</button>
      </div>
    </div>
  );
};
