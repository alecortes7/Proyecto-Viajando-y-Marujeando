/* eslint-disable no-unused-vars */
import { Col, Container, Row } from 'react-bootstrap'
import { useLocation, useNavigate } from 'react-router-dom';
import './bookingServices.css'
import axios from 'axios';
import { useEffect, useState } from 'react';

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const BookingServices = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { parcela, startDate, endDate, formattedDateStart, formattedDateEnd } = location.state || {};
  const [servicesFree, setServicesFree] = useState([]);
  const [services, setServices] = useState([]);
  const [serviciosSinReserva, setServiciosSinReserva] = useState([])
  const [contador, setContador] = useState()
  const [precioFinal, setPrecioFinal] = useState(0)

  useEffect(() => {
    const obtenerServicios = async () => {
      try {
        let res = await axios.get(`${apiUrl}reservas/getServices`);
        const servicios = res.data.filter(service => 
          service.service_price !== "0.00" &&
          service.service_name !== "Lavadora" &&
          service.service_name !== "Secadora" &&
          service.service_name !== "Lava mascotas"
        );
        const serviciosSinReserva = res.data.filter(service => 
          service.service_name === "Lavadora" ||
          service.service_name === "Secadora" ||
          service.service_name === "Lava mascotas"
        );
        
        const serviciosGratis = res.data.filter(service => service.service_price === "0.00");
        setServicesFree(serviciosGratis);
        setServices(servicios);
        setServiciosSinReserva(serviciosSinReserva);
      } catch (error) {
        console.log(error)
      }
    }
    obtenerServicios();
  }, [])
  
  // Inicializar el contador con el mismo tamaño que el array de servicios, solo cuando se inicialicen los servicios
  useEffect(() => {
    setContador(services.map(() => 0));
  }, [services]);

  useEffect(() => {
    if (parcela) {
      calcFinalPrice(services, contador);
    }
  }, [parcela, services, contador]);

  const addServiceIncrease = (index, price) => {
    const conntTemp = [...contador];
    const serviceName = services[index].service_name;

    // Condiciones para limitar ciertos servicios
    if (serviceName === 'Luz en parcela' && conntTemp[index] >= 1) return;
    if (serviceName === 'Sombra en parcela' && conntTemp[index] >= 1) return;
    if (serviceName === 'Sombra en parcela' && reservationDays < 3) return;
    if (serviceName === 'Jacuzzi' && conntTemp[index] >= 1) return;
    if (serviceName === 'Jacuzzi' && reservationDays < 3) return;
    if (serviceName === 'Persona extra (+3 años)' && conntTemp[index] >= 4) return;

    conntTemp[index] += 1;
    setContador(conntTemp);
    calcFinalPrice(services, conntTemp);
  }

  const addServiceDecrease = (index, price) => {
    const conntTemp = [...contador];
    if (conntTemp[index] > 0){
      conntTemp[index] -= 1;
      setContador(conntTemp);
      calcFinalPrice(services, conntTemp);
    }
  }

  const calcFinalPrice = (services, contador) => {
    if (!services || !contador || services.length === 0 || contador.length === 0) {
      return;
    }
    
    let resultado = 0;
    for (let i = 0; i < contador.length; i++) {
      resultado += contador[i] * parseFloat(services[i].service_price)
    }

    if (parcela && reservationDays){
      setPrecioFinal((resultado * reservationDays) + (parcela.parcel_price * reservationDays));
    }
  }
  
  // Calcular la duración de la reserva en días
  const calculateDays = (start, end) => {
    const startDateObj = new Date(start);
    const endDateObj = new Date(end);
    
    // Establecer la hora a medianoche (00:00:00)
    startDateObj.setHours(0, 0, 0, 0);
    endDateObj.setHours(0, 0, 0, 0);
    
    const timeDiff = endDateObj - startDateObj; // Diferencia en milisegundos
    return Math.floor(timeDiff / (1000 * 3600 * 24)); // Convertir a días
  };
  
  const reservationDays = calculateDays(startDate, endDate);

  const handlePrevPage = () => {
    navigate(-1); // Navega a la página anterior
  };

  const handleCancel = () => {
    navigate('/'); // Navega al home
  };

  const handleNextPage = () => {
    // Navega a la página siguiente
    navigate('/bookingInfo', {
      state: {
        parcela: parcela,
        startDate: startDate,
        endDate: endDate,
        precioFinal: precioFinal,
        formattedDateStart,
        formattedDateEnd,
        services,
        contador
      }
    }) 
  };

  return (
    <Container fluid className="static-container2 bg-image-sp2 gap-3">
    <h2 className="text-center">Servicios</h2>
    <Row>
      <Col md={6} className='d-flex flex-column justify-content-evenly gap-2 text-center'>
        
        <div className="static-div2">
          <h4>Servicios incluidos:</h4>
          <ul className='d-flex flex-column align-items-center p-1'>
            {servicesFree?.map((serv) => {
              return(
                <li key={serv.service_id}>{serv.service_name}</li>
              )
            })}
          </ul>
        </div>
        <div className="static-div2">
          <h4>Servicios que se pueden contratar en el camping:</h4>
          <ul className='d-flex flex-column align-items-center p-1'>
            <li>Vaciado de fosa séptica Precio: 5.00€</li>
            {serviciosSinReserva?.map((serv) => {
              return(
                <li key={serv.service_id}>{serv.service_name} Precio: {serv.service_price} €</li>
              )
            })}
          </ul>
        </div>
      </Col>
      <Col md={6} className='d-flex flex-column justify-content-evenly text-center'>
        <div className="static-div2 mb-2">
        <h4>Servicios adicionales:</h4>
          <br />
          <ul className='d-flex flex-column gap-2'>
            {services?.map((serv, index) => {
                return(
                  <li key={serv.service_id}>
                    {serv.service_name} Precio: {serv.service_price} €
                    <div className='d-flex gap-2'>
                      <button className='btn-default add-sub-btn' onClick={()=>addServiceDecrease(index, serv.service_price)}>-</button>
                      <div className='btn-default add-sub-btn'>{contador[index]}</div>
                      <button className='btn-default add-sub-btn' onClick={()=>addServiceIncrease(index, serv.service_price)}>+</button>
                    </div>
                  </li>
                )
              })}
          </ul>
          <p>Total: {precioFinal} €</p>
        </div>
      </Col>
    </Row>
    <Row>
        <div className='btn-div'>
          <button className='btn-default' onClick={handlePrevPage}>Atrás</button>
          <button className='btn-default' onClick={handleCancel}>Cancelar</button>
          <button className='btn-default' onClick={handleNextPage}>Siguiente</button>
        </div>
    </Row>
  </Container>
  )
}
