/* eslint-disable react/prop-types */

import { Button, Modal } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom';

export const ModalReservaOk = ({showReservaOk, setShowReservaOk}) => {
  const navigate = useNavigate();

  const handleClose = () => {
    setShowReservaOk(false);
    navigate('/');
  }

  return (
    <>
    <Modal show={showReservaOk} onHide={handleClose}>
    <Modal.Header closeButton>
      <Modal.Title>Reserva realizada correctamente</Modal.Title>
    </Modal.Header>
    <Modal.Body>
    <p className="text-success">En su perfil encontrará los datos de la reserva realizada</p>
    </Modal.Body>
    <Modal.Footer>
      <Button variant="secondary" onClick={handleClose} className='btn-default'>
        Cerrar
      </Button>
    </Modal.Footer>
  </Modal>
    </>
  )
}
