import './errorPage.css'
import error from '../../assets/images/404.png'
import { Link } from 'react-router-dom'

export const ErrorPage = () => {

  return (
    <div className='errorpage-main container-fluid'>
      <div className='texto-error'>
        <img src={error} alt="pagina no encontrada" />
        <h3>La página que busca no existe</h3>
        <p>Ir a <Link to="/">Inicio</Link> </p>
      </div>
    </div>
  )
}
