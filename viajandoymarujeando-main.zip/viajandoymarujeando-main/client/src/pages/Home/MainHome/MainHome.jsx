import { Container, Row, Col } from 'react-bootstrap';
import './MainHome.css';

export const MainHome = () => {

  return (
    <Container fluid>
      <Row className="bg-image-row">
        <Col className="d-flex justify-content-center justify-content-md-end align-items-center">
          <div className='d-flex align-items-center bienvenida-main'>
            <h1>Bienvenido a nuestra área</h1>
          </div>
        </Col>
      </Row>
      <Row className="d-flex flex-column align-items-center gap-3 py-5 bg-services-row">
        <Row>
          <Col className="text-center">
            <h2>Nuestros servicios</h2>
          </Col>
        </Row>
        <Row className='d-flex flex-column flex-xl-row gap-3'>
          <Col className='d-flex flex-column flex-md-row gap-3 justify-content-center'>
            <Row className='d-flex flex-column gap-3'>
              <Col className='d-flex justify-content-center'>
                <img src="/MainHome/caravana.jpg" alt="" className="img-mainhome" />
              </Col>
              <Col className='d-flex justify-content-center'>
                <img src="/MainHome/perros.jpg" alt="" className="img-mainhome" />
              </Col>
            </Row>
            <Row className='d-flex flex-column gap-3'>
              <Col className='d-flex justify-content-center'>
                <img src="/MainHome/rutabici.jpg" alt="" className="img-mainhome" />
              </Col>
              <Col className='d-flex justify-content-center'>
                <img src="/MainHome/camper-familiar.jpg" alt="" className="img-mainhome" />
              </Col>
            </Row>
          </Col>
          <Col>
            <Row className='h-100'>
              <Col className='h-100 d-flex flex-column justify-content-around align-items-center icon-width gap-2 gap-xl-0'>
                <p>
                  <img src="/MainHome/senderismo.png" alt="Icono Servicio 1" className="icono-servicio" />
                  Senderismo
                </p>
                <p>
                  <img src="/MainHome/tienda.png" alt="Icono Servicio 2" className="icono-servicio" />
                  Tienda
                </p>
                <p>
                  <img src="/MainHome/verduras.png" alt="Icono Servicio 3" className="icono-servicio" />
                  Huerto
                </p>
              </Col>
              <Col className='h-100 d-flex flex-column justify-content-around align-items-center icon-width gap-2 gap-xl-0'>
                <p>
                  <img src="/MainHome/playa.png" alt="Icono Servicio 4" className="icono-servicio" />
                  Playa
                </p>
                <p>
                  <img src="/MainHome/lavanderia.png" alt="Icono Servicio 5" className="icono-servicio" />
                  Lavanderia
                </p>
                <p>
                  <img src="/MainHome/jacuzzi.png" alt="Icono Servicio 6" className="icono-servicio" />
                  Jacuzzi
                </p>
              </Col>
            </Row>
          </Col>
        </Row>
      </Row>
    </Container>
  )
}
