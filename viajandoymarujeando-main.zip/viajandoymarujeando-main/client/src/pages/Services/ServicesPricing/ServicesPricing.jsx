import { useEffect, useState } from 'react'
import { Container, Row, Col } from 'react-bootstrap';
import '../../StaticPages/StaticPages.css'
import './ServicesPricing.css'
import axios from 'axios';

const apiUrl = import.meta.env.VITE_SERVER_URL;

export const ServicesPricing = () => {
  const [servicesFree, setServicesFree] = useState([]);
  const [services, setServices] = useState([]);

  useEffect(() => {

    const obtenerServicios = async () => {
      try {
        let res = await axios.get(`${apiUrl}getServices/`);
        
        const servicios = res.data.filter(service => service.service_price !== "0.00");
        const serviciosGratis = res.data.filter(service => service.service_price === "0.00");

        setServicesFree(serviciosGratis);
        setServices(servicios);
        
      } catch (error) {
        console.log(error)
      }
    }

    obtenerServicios();

  }, [])


  return (
    <Container fluid className="static-container bg-image-sp mx-0 py-5">
      <h2 className="text-center mb-4">Tarifas</h2>
      <Row className='h-75'>
        <Col md={6} className='d-flex flex-column justify-content-between gap-4'>
          <div className="static-div w-100">
          <h4>Nuestros Precios:</h4>
          <ul>
            <li>Estancia diaria: 12€ al día, check-in y check-out a las 12h</li>
          </ul>
          </div>
          <div className="static-div w-100">
            <h4>El precio incluye:</h4>
            <ul>
              {servicesFree?.map((serv) => {
                return(
                  <li key={serv.service_id}>{serv.service_name}</li>
                )
              })}
            </ul>
          </div>
        </Col>
        <Col md={6} className='d-flex align-items-end mt-3 mt-md-0'>
          <div className="static-div w-100">
            <p>
            A continuación te mostramos la lista completa y precios de los distintos servicios que disponemos, estos son opcionales y se podrán elegir a la hora de realizar tu reserva.
            </p>
            <br />
            <ul>
            {services?.map((serv) => {
                return(
                  <li key={serv.service_id}>{serv.service_name} Precio: {serv.service_price} €</li>
                )
              })}
            </ul>
          </div>
        </Col>
      </Row>
    </Container>
  )
}
