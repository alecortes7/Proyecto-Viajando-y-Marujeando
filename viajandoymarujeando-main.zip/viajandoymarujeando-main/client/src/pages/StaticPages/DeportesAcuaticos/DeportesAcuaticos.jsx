import { Container, Row, Col } from 'react-bootstrap';
import '../StaticPages.css'
import './DeportesAcuaticos.css'

export const DeportesAcuaticos = () => {
  return (
    <Container fluid className="static-container bg-image-da">
      <h2 className="text-center mb-4 text-white py-3">Deportes Acuáticos</h2>
      <Row className='h-75 row-gap-5 mt-4'>
        <Col md={12} className='d-flex align-items-start'>
          <div className="static-div">
            <p>
            Castellón de la Plana es un destino ideal para los amantes de los deportes acuáticos, gracias a su costa bañada por el Mediterráneo y sus condiciones climáticas favorables durante todo el año. En el Grao de Castellón, el puerto deportivo se ha convertido en un punto clave para quienes desean practicar deportes como la vela. Con varias escuelas náuticas en la zona, es posible iniciarse en este deporte o perfeccionar técnicas, con cursos disponibles para todas las edades y niveles.
            El windsurf y el kitesurf también son muy populares en las playas de Castellón, especialmente en la Playa del Gurugú, que es conocida por sus vientos favorables. Tanto principiantes como expertos pueden disfrutar de estas disciplinas, y la playa cuenta con áreas reservadas para practicar de manera segura.
            </p>
          </div>
        </Col>
        <Col md={12} className='d-flex align-items-end mt-3 mt-md-0'>
          <div className="static-div d-flex ms-auto">
            <p>
            El paddle surf o SUP (stand-up paddle) ha ganado popularidad en los últimos años. Este deporte, que combina equilibrio y relajación, permite recorrer la costa de una manera tranquila mientras disfrutas del paisaje marino. En la Playa del Pinar, es común ver a grupos de personas practicando paddle surf durante las primeras horas del día.
            El kayak es otra opción excelente para explorar el litoral de Castellón. Alquilar un kayak y navegar cerca de la costa ofrece una experiencia única, permitiendo descubrir calas escondidas y disfrutar de la tranquilidad del mar.
            Con sus aguas cristalinas y múltiples actividades, Castellón es un destino perfecto para los aficionados a los deportes acuáticos.
            </p>
          </div>
        </Col>
      </Row>
    </Container>
  )
}
