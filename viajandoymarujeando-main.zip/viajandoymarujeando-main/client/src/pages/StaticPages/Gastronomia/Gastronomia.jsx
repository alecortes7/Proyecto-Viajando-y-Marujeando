import { Container, Row, Col } from 'react-bootstrap';
import '../StaticPages.css'
import './Gastronomia.css'

export const Gastronomia = () => {
  return (
    <Container fluid className="static-container bg-image-g">
      <h2 className="text-center mb-4 text-white py-3">Gastronomía</h2>
      <Row className='h-75 row-gap-5 mt-4'>
        <Col md={12} className='d-flex align-items-start'>
          <div className="static-div">
            <p>
            La gastronomía de Castellón de la Plana refleja la esencia mediterránea, con una mezcla de sabores frescos del mar y productos de la huerta, creando una cocina rica y variada. Gracias a su ubicación costera y su cercanía a las montañas, Castellón ofrece una amplia gama de platos tradicionales que combinan mariscos, pescados, arroces y carnes.
            Uno de los pilares de la cocina castellonense es el arroz, protagonista de numerosos platos. Entre ellos, destaca la paella, que en esta zona se prepara tanto en su versión tradicional con pollo y conejo, como con mariscos frescos del Mediterráneo. El arroz a banda, cocinado en caldo de pescado, es otro de los clásicos que se pueden disfrutar en los restaurantes locales, especialmente en la zona del Grao de Castellón, donde abundan los chiringuitos y restaurantes con vistas al mar.
            </p>
          </div>
        </Col>
        <Col md={12} className='d-flex align-items-end mt-3 mt-md-0'>
          <div className="static-div d-flex ms-auto">
            <p>
            toque de alioli, es una de las especialidades más apreciadas. También son muy populares los boquerones, las sardinas a la brasa y los calamares, que se sirven frescos y preparados de diversas formas. La pesca local garantiza la frescura de estos ingredientes.
            Los productos de la huerta valenciana también juegan un papel importante. Las verduras, como las alcachofas, los pimientos y los tomates, se utilizan en ensaladas, guisos y como acompañamiento de platos principales. En este sentido, la olla de la Plana, un guiso tradicional de la zona, combina legumbres y verduras con carne de cerdo, ofreciendo una comida reconfortante y sabrosa.
            Para acompañar estas delicias, es común degustar vinos de la región, como los de la Denominación de Origen Castellón, que incluyen tintos y blancos con carácter. En resumen, la gastronomía de Castellón de la Plana es una celebración de los productos frescos y de calidad, donde el mar y la tierra se fusionan en cada plato.
            </p>
          </div>
        </Col>
      </Row>
    </Container>
  )
}
