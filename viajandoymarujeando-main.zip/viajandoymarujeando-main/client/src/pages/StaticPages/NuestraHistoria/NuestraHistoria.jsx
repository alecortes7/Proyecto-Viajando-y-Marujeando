import { Row, Col } from 'react-bootstrap';
import '../StaticPages.css'
import './NuestraHistoria.css'

export const NuestraHistoria = () => {
  return (
   
      <div className='container-fluid static-container bg-image-nh'>
        <h2 className="text-center mb-4 text-white py-3 mt-4">Nuestra Historia</h2>
        <Row className='h-75 row-gap-5'>
          <Col md={12} className='d-flex align-items-start'>
            <div className="static-div">
              <p>
              Castellón de la Plana, situada en la Comunidad Valenciana, es una ciudad costera con un importante atractivo turístico gracias a sus playas y clima mediterráneo. Entre sus principales playas destaca la Playa del Pinar, ubicada en el distrito marítimo del Grao. Con una extensión de 1.800 metros, esta playa de arena fina y dorada es perfecta para familias y deportistas. Ofrece diversos servicios, como zonas de juegos, áreas deportivas y accesibilidad para personas con movilidad reducida.
              Otra playa importante es la Playa del Gurugú, conocida por su ambiente juvenil y la presencia de chiringuitos que ofrecen música en vivo y vida nocturna. Con sus 1.200 metros, es ideal para la práctica de deportes acuáticos como el windsurf y el kitesurf. Además, cuenta con un paseo marítimo que invita a correr o pasear.
              </p>
            </div>
          </Col>
          <Col md={12} className='d-flex align-items-end mt-3 mt-md-0'>
            <div className="static-div d-flex ms-auto">
              <p>
              La Playa Serradal es más tranquila y destaca por su sistema dunar y su entorno natural. Con más de 2 kilómetros de longitud, es ideal para quienes buscan un ambiente relajado y disfrutar de la biodiversidad marina, siendo muy popular entre los aficionados al snorkel.
              En los alrededores, localidades como Benicàssim ofrecen más opciones de playas, como la Playa de Heliópolis, perfecta para largas caminatas o deportes acuáticos. En definitiva, las playas de Castellón ofrecen un equilibrio entre ocio, deporte y relax, convirtiendo la zona en un destino perfecto para disfrutar del Mediterráneo.
              </p>
            </div>
          </Col>
        </Row>
      </div>    
  )
}
