import { Container, Row, Col } from 'react-bootstrap';
import '../StaticPages.css'
import './QueHacer.css'

export const QueHacer = () => {
  return (
    <Container fluid className="static-container bg-image-qh">
      <h2 className="text-center mb-4 text-white py-3">Que Hacer</h2>
      <Row className='h-75 row-gap-5 mt-4'>
        <Col md={12} className='d-flex align-items-start'>
          <div className="static-div">
            <p>
            Castellón de la Plana ofrece una gran variedad de actividades para todo tipo de visitantes. En el centro de la ciudad, puedes comenzar explorando la Plaza Mayor, donde se encuentran algunos de los edificios más emblemáticos, como el Ayuntamiento y la Concatedral de Santa María, una construcción gótica que ha sido reconstruida a lo largo de los siglos. Justo al lado, se alza el Fadrí, una torre campanario que es uno de los símbolos de Castellón.
            Para los amantes de la naturaleza, un paseo por el Parque Ribalta es una excelente opción. Este jardín de estilo romántico es ideal para relajarse o disfrutar de una caminata al aire libre. Si te gusta la aventura, a poca distancia de la ciudad se encuentra el Desierto de las Palmas, un parque natural con rutas de senderismo que ofrecen impresionantes vistas al mar y al interior montañoso.
            </p>
          </div>
        </Col>
        <Col md={12} className='d-flex align-items-end mt-3 mt-md-0'>
          <div className="static-div d-flex ms-auto">
            <p>
            La costa de Castellón también es imprescindible. En el Grao de Castellón, el puerto deportivo ofrece actividades acuáticas como vela, windsurf o kayak. También puedes relajarte en sus playas, como la Playa del Pinar, y disfrutar de los chiringuitos y restaurantes que ofrecen deliciosa gastronomía local, donde el pescado y el arroz son protagonistas.
            Para los interesados en la cultura, el Museo de Bellas Artes de Castellón y el Espai d'Art Contemporani son espacios donde se pueden apreciar tanto obras clásicas como modernas. Castellón combina historia, naturaleza y ocio, brindando experiencias para todos los gustos.
            </p>
          </div>
        </Col>
      </Row>
    </Container>
  )
}
