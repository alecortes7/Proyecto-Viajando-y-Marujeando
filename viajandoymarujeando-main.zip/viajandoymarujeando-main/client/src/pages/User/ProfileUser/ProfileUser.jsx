/* eslint-disable no-unused-vars */
import { useNavigate } from 'react-router-dom'
import Card from "react-bootstrap/Card";
import foto from "../../../assets/images/perfilDefault.jpg";
import Table from "react-bootstrap/Table";
import './profileUser.css'
import { useContext, useEffect, useState } from 'react';
import { CampingContext } from '../../../context/ContextProvider';
import axios from 'axios';
import { FormEditUser } from '../../../components/FormEditUser/FormEditUser';
const apiUrl = import.meta.env.VITE_SERVER_URL;

export const ProfileUser = () => {

  const navigate = useNavigate()
  const { user, token } = useContext(CampingContext)
  const [listaReservas, setListaReservas] = useState();
  const [showFormEditUser, setShowFormEditUser] = useState(false);

  useEffect(() => {
    const getUserData = async () => {
      try {
        if (user) {
          let res = await axios.get(`${apiUrl}reservas/getUserBooking/${user?.user_id}`);

          setListaReservas(res.data);

        }

      } catch (error) {
        console.log(error)
      }
    }

    getUserData();

  }, [user])


  return (
    <>
    <div className="profile-user d-flex container-fluid justify-content-center row">
          <div className="col-sm-12 col-md-5 col-xl-4">
            <div className="card-profile">
              <Card className='d-flex mx-auto' style={{ width: "18rem", padding: "0.5rem", backgroundColor: " rgb(227, 222, 222,85%)" }}>
                <Card.Img variant="top" src={user?.image ? `${apiUrl}images/users/${user.image}` : foto} className='img-perfil' />
                <Card.Body>
                  <Card.Title>{user?.user_name} {user?.lastname}</Card.Title>
                  <Card.Text>
                    {user?.email}
                  </Card.Text>
                  <Card.Text style={{ paddingBlock: "0.5rem" }}>{user?.phone}</Card.Text>
                  <Card.Text style={{ paddingBlock: "0.5rem" }}>{user?.dni}</Card.Text>
                  <button className="btn-default" onClick={()=> {setShowFormEditUser(true)}}>
                    Modificar datos
                  </button>
                </Card.Body>
              </Card>
            </div>
          </div>
          <div className="col-sm-12 col-md-7 col-xl-8">
            <div className="d-flex justify-content-center flex-column">
              <h2 className='text-center text-white'>Tus reservas</h2>
              <div className='table-responsive'>
                <Table striped bordered hover>
                  <thead>
                    <tr>
                      <th className='text-center'>Nº reserva</th>
                      <th className='text-center'>Parcela</th>
                      <th className='text-center'>Entrada</th>
                      <th className='text-center'>Salida</th>
                      <th className='text-center'>Servicios contratados</th>
                    </tr>
                  </thead>
                  <tbody>
                    {listaReservas?.map((reserva) => {
                      return (
                        <tr key={reserva.booking_id}>
                          <td className='text-center'>{reserva.booking_id}</td>
                          <td className='text-center'>{reserva.parcel_name}</td>
                          <td className='text-center'>{reserva.date_start}</td>
                          <td className='text-center'>{reserva.date_end}</td>
                          <td className='text-center'>{reserva.service_names ? reserva.service_names : "Sin servicios extras" }</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </Table>
              </div>
            </div>
          </div>
    </div>
    <FormEditUser showFormEditUser={showFormEditUser} setShowFormEditUser={setShowFormEditUser}/>
    </>
  );
};
