CREATE DATABASE viajandoymarujeando;

USE viajandoymarujeando;


CREATE TABLE user (
    user_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    user_name VARCHAR(100) NOT NULL,
    lastname VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(25) NOT NULL,
    dni VARCHAR(20) NOT NULL,
    address VARCHAR(255),
    province VARCHAR(100),
    city VARCHAR(100),
    country VARCHAR(100),
    user_type TINYINT NOT NULL DEFAULT 2, -- 2 -> por defecto es un cliente
    image VARCHAR(255),
    enabled_status TINYINT UNSIGNED NOT NULL DEFAULT 1 -- 1 -> está registrado (pendiente confirmar por email)
);




CREATE TABLE parcel (
    parcel_id INT AUTO_INCREMENT PRIMARY KEY,
    parcel_name VARCHAR(100) UNIQUE NOT NULL,
    area DECIMAL(6,2) NOT NULL,  -- 9999,99
    parcel_price DECIMAL(6,2) NOT NULL,  -- 9999,99
    parcel_available BOOLEAN NOT NULL DEFAULT TRUE,  -- el admin puede marcarla como no disponible para alquiler
	coordinates VARCHAR(300) NOT NULL
);

INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("A1", 70, 12, "14, 203, 67, 203, 67, 226, 14, 226");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("A2", 70, 12, "14, 233, 67, 233, 67, 256, 14, 256");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("A3", 70, 12, "14, 262, 67, 262, 67, 286, 14, 286");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("A4", 70, 12, "14, 292, 67, 292, 67, 316, 14, 316");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("A5", 70, 12, "14, 322, 67, 322, 67, 346, 14, 346");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("A6", 70, 12, "14, 352, 67, 352, 67, 376, 14, 376");

INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("B1", 70, 12, "350, 13, 374, 13, 374, 67, 350, 67");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("B2", 70, 12, "380, 13, 404, 13, 404, 67, 380, 67");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("B3", 70, 12, "410, 13, 434, 13, 434, 67, 410, 67");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("B4", 70, 12, "440, 13, 464, 13, 464, 67, 440, 67");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("B5", 70, 12, "470, 13, 494, 13, 494, 67, 470, 67");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("B6", 70, 12, "500, 13, 524, 13, 524, 67, 500, 67");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("B7", 70, 12, "530, 13, 554, 13, 554, 67, 530, 67");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("B8", 70, 12, "560, 13, 584, 13, 584, 67, 560, 67");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("B9", 70, 12, "589, 13, 614, 13, 614, 67, 589, 67");

INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C1", 70, 12, "147, 120, 170, 120, 170, 173, 147, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C2", 70, 12, "177, 120, 200, 120, 200, 173, 177, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C3", 70, 12, "207, 120, 230, 120, 230, 173, 207, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C4", 70, 12, "237, 120, 260, 120, 260, 173, 237, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C5", 70, 12, "267, 120, 290, 120, 290, 173, 267, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C6", 70, 12, "297, 120, 320, 120, 320, 173, 297, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C7", 70, 12, "327, 120, 350, 120, 350, 173, 327, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C8", 70, 12, "356, 120, 380, 120, 380, 173, 356, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C9", 70, 12, "386, 120, 410, 120, 410, 173, 386, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C10", 70, 12, "416, 120, 440, 120, 440, 173, 416, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C11", 70, 12, "446, 120, 470, 120, 470, 173, 446, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C12", 70, 12, "475, 120, 500, 120, 500, 173, 475, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C13", 70, 12, "505, 120, 530, 120, 530, 173, 505, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C14", 70, 12, "535, 120, 560, 120, 560, 173, 535, 173");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("C15", 70, 12, "565, 120, 590, 120, 590, 173, 565, 173");

INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D1", 70, 12, "119, 226, 142, 226, 142, 280, 119, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D2", 70, 12, "149, 226, 172, 226, 172, 280, 149, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D3", 70, 12, "179, 226, 202, 226, 202, 280, 179, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D4", 70, 12, "208, 226, 232, 226, 232, 280, 208, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D5", 70, 12, "238, 226, 261, 226, 261, 280, 238, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D6", 70, 12, "268, 226, 291, 226, 291, 280, 268, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D7", 70, 12, "298, 226, 320, 226, 320, 280, 298, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D8", 70, 12, "328, 226, 350, 226, 350, 280, 328, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D9", 70, 12, "357, 226, 380, 226, 380, 280, 357, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D10", 70, 12, "387, 226, 410, 226, 410, 280, 387, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D11", 70, 12, "417, 226, 440, 226, 440, 280, 417, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D12", 70, 12, "447, 226, 469, 226, 469, 280, 447, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D13", 70, 12, "477, 226, 499, 226, 499, 280, 477, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D14", 70, 12, "507, 226, 529, 226, 529, 280, 507, 280");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("D15", 70, 12, "536, 226, 559, 226, 559, 280, 536, 280");

INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E1", 70, 12, "87, 332, 111, 332, 111, 385, 87, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E2", 70, 12, "117, 332, 141, 332, 141, 385, 117, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E3", 70, 12, "147, 332, 171, 332, 171, 385, 147, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E4", 70, 12, "177, 332, 201, 332, 201, 385, 177, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E5", 70, 12, "206, 332, 229, 332, 230, 385, 206, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E6", 70, 12, "236, 332, 259, 332, 260, 385, 236, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E7", 70, 12, "266, 332, 289, 332, 290, 385, 266, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E8", 70, 12, "296, 332, 319, 332, 320, 385, 296, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E9", 70, 12, "326, 332, 349, 332, 350, 385, 326, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E10", 70, 12, "356, 332, 379, 332, 380, 385, 356, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E11", 70, 12, "386, 332, 409, 332, 410, 385, 386, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E12", 70, 12, "415, 332, 438, 332, 439, 385, 415, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E13", 70, 12, "445, 332, 468, 332, 469, 385, 445, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E14", 70, 12, "475, 332, 498, 332, 499, 385, 475, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E15", 70, 12, "505, 332, 528, 332, 529, 385, 505, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E16", 70, 12, "534, 332, 558, 332, 559, 385, 534, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E17", 70, 12, "564, 332, 588, 332, 589, 385, 564, 385");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("E18", 70, 12, "594, 332, 618, 332, 619, 385, 594, 385");

INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F1", 70, 12, "634, 24, 688, 24, 688, 47, 634, 47");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F2", 70, 12, "634, 54, 688, 54, 688, 77, 634, 77");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F3", 70, 12, "634, 84, 688, 84, 688, 107, 634, 107");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F4", 70, 12, "634, 114, 688, 114, 688, 137, 634, 137");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F5", 70, 12, "634, 144, 688, 144, 688, 167, 634, 167");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F6", 70, 12, "634, 173, 688, 173, 688, 197, 634, 197");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F7", 70, 12, "634, 203, 688, 203, 688, 227, 634, 227");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F8", 70, 12, "634, 233, 688, 233, 688, 257, 634, 257");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F9", 70, 12, "634, 263, 688, 263, 688, 287, 634, 287");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F10", 70, 12, "634, 292, 688, 292, 688, 317, 634, 317");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F11", 70, 12, "634, 322, 688, 322, 688, 347, 634, 347");
INSERT INTO parcel (parcel_name, area, parcel_price, coordinates) VALUES ("F12", 70, 12, "634, 352, 688, 352, 688, 377, 634, 377");




CREATE TABLE service (
    service_id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    service_description VARCHAR(400),
    service_price DECIMAL(10,2) NOT NULL, -- 99999999,99
    service_image VARCHAR(255),
    service_is_deleted BOOLEAN NOT NULL DEFAULT FALSE
);

INSERT INTO `service` VALUES (11,'1 A/C o camper','Aire acondicionado',0.00,'Id-1729086278540-aireAcondicionado.jpg',0),(12,'2 Personas','La reserva incluye dos personas',0.00,'Id-1729087517948-camper-familiar.jpg',0),(13,'Aseos y duchas con agua caliente','Disponibles aseos y duchas en el recinto',0.00,'Id-1729087656243-ducha.jpg',0),(14,'Agua potable y vaciado de fosa séptica','Disponibilidad de agua potable y vaciado de residuos.',0.00,'Id-1729087714842-fosa.jpg',0),(15,'Niños hasta 3 años','Los niños menores de 3 años están incluidos con la reserva',0.00,'Id-1729087742241-camper-familiar.jpg',0),(16,'Mascota','Mascotas permitidas e incluidas con la reserva.',0.00,'Id-1729087750531-perros.jpg',0),(17,'Luz en parcela','El precio es por día.',5.00,'Id-1729087808082-luz.webp',0),(18,'Persona extra (+3 años)','El máximo es de 6 personas por parcela y el precio es por día',6.00,'Id-1729087824154-camper-familiar.jpg',0),(19,'Coche Adicional','Numero ilimitado de plazas, precio por día.',2.00,'Id-1729087877562-coche.jpg',0),(20,'Moto o remolque','Precio por día',1.00,'Id-1729087908371-moto.jpg',0),(21,'Lavadora','Precio por lavado.',5.00,'Id-1729087949914-lavadora.jpg',0),(22,'Secadora','Precio por secado',3.00,'Id-1729087987930-secadora.jpg',0),(23,'Lava mascotas','Precio por lavado.',6.00,'Id-1729088026338-lavamascota.jpg',0),(24,'Jacuzzi','Mínimo 3 días, precio por día, se necesitara fianza de 300€ que se devolverá tras comprobar el estado al finalizar la reserva.',12.00,'Id-1729088056689-jacuzzi.webp',0),(25,'Sombra en parcela','Mínimo de 3 días.',5.00,'Id-1729088094403-sombra.jpg',0);




CREATE TABLE booking (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    parcel_id INT NOT NULL,
    date_start DATE NOT NULL,
    date_end DATE NOT NULL,
    booking_is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_user_1 FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_parcel_1 FOREIGN KEY (parcel_id) REFERENCES parcel(parcel_id) ON DELETE CASCADE
);

CREATE TABLE booking_service (
    booking_id INT NOT NULL,
    service_id INT NOT NULL,
    amount INT, -- la cantidad puede ser NULA para algunos servicios
    PRIMARY KEY (booking_id, service_id),
    CONSTRAINT fk_booking_1 FOREIGN KEY (booking_id) REFERENCES booking(booking_id) ON DELETE CASCADE,
    CONSTRAINT fk_service_1 FOREIGN KEY (service_id) REFERENCES service(service_id) ON DELETE CASCADE
);

