import { validationResult } from "express-validator";
import connection from "../config/db.js";

class AdminController {
  admin = (req, res) => {
    res.status(200).json("admin");
  };

  getAllUsers = (req, res) => {
    let sql = 'SELECT * FROM user WHERE user_type = 2'
    connection.query(sql, (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Error al obtener los usuarios', details: err });
      } else {
        res.status(200).json({ users: result })
      }
    })
  }

  deshabilitarUser = (req, res) => {

    const user_id = req.params.user_id;
    let sql = "UPDATE user SET enabled_status = 3 WHERE user_id = ?";
    connection.query(sql, [user_id], (err, result) => {
      if (err) {
        return res
          .status(500)
          .json({ error: "Error al actualizar el usuario", details: err });
      } else {
        res.status(200).json({ message: "Usuario actualizado" });
      }
    });
  };

  habilitarUser = (req, res) => {

    const user_id = req.params.user_id;
    let sql = "UPDATE user SET enabled_status = 2 WHERE user_id = ?";
    connection.query(sql, [user_id], (err, result) => {
      if (err) {
        return res
          .status(500)
          .json({ error: "Error al actualizar el usuario", details: err });
      } else {
        res.status(200).json({ message: "Usuario actualizado" });
      }
    });
  };

  addService = (req, res) => {

    const { service_name, service_description, service_price } = req.body;

    //Comprobar datos para validarlos
    const errorValidacion = validationResult(req);

    if (!errorValidacion.isEmpty()) {
      const errores = errorValidacion.array();
      res.status(400).json(errores)
    } else {

      let sql = 'INSERT INTO service (service_name, service_description, service_price) VALUES (?, ?, ?)';
      let values = [service_name, service_description, service_price];

      if (req.file) {
        sql = 'INSERT INTO service (service_name, service_description, service_price, service_image) VALUES (?, ?, ?, ?)';
        values = [service_name, service_description, service_price, req.file.filename];
      }

      connection.query(sql, values, (err, result) => {
        if (err) {
          res.status(500).json(err)
        } else {
          res.status(200).json(result)
        }
      })
    }
  }

  getAllServices = (req, res) => {
    let sql = 'SELECT * FROM service'

    connection.query(sql, (err, result) => {
      if (err) {
        res.status(500).json(err)
      } else {
        res.status(200).json(result)
      }
    })
  }

  getAdminBookings = (req, res) => {
    let sql = `SELECT 
      b.booking_id,
      b.date_start,
      b.date_end,
      b.booking_is_deleted,
      p.parcel_name,
      p.area,
      p.parcel_price,
      p.parcel_available,
      p.coordinates,
      u.user_name, 
    GROUP_CONCAT(srv.service_name SEPARATOR ', ') AS service_names,
    GROUP_CONCAT(s.amount SEPARATOR ', ') AS service_amounts
    FROM 
      booking b
    JOIN 
      parcel p ON b.parcel_id = p.parcel_id
    JOIN 
      user u ON b.user_id = u.user_id
    LEFT JOIN 
      booking_service s ON b.booking_id = s.booking_id
    LEFT JOIN 
      service srv ON s.service_id = srv.service_id
    GROUP BY 
      b.booking_id, u.user_name
    ORDER BY 
      b.booking_id DESC`;
    connection.query(sql, (err, result) => {
      if (err) {
        res.status(500).json(err)
      }
      else {
        res.status(200).json(result)
      }
    })
  }


  getAdminBookings = (req, res) => {
    let sql = `SELECT 
      b.booking_id,
      b.date_start,
      b.date_end,
      b.booking_is_deleted,
      p.parcel_name,
      p.area,
      p.parcel_price,
      p.parcel_available,
      p.coordinates,
      u.user_name, 
    GROUP_CONCAT(srv.service_name SEPARATOR ', ') AS service_names,
    GROUP_CONCAT(s.amount SEPARATOR ', ') AS service_amounts
    FROM 
      booking b
    JOIN 
      parcel p ON b.parcel_id = p.parcel_id
    JOIN 
      user u ON b.user_id = u.user_id
    LEFT JOIN 
      booking_service s ON b.booking_id = s.booking_id
    LEFT JOIN 
      service srv ON s.service_id = srv.service_id
    GROUP BY 
      b.booking_id, u.user_name`;
    connection.query(sql, (err, result) => {
      if (err) {
        res.status(500).json(err)
      }
      else {
        res.status(200).json(result)
      }
    })
  }


  editService = (req, res) => {
    const { service_id, service_name, service_description, service_price, service_is_deleted } = req.body;

    //Comprobar validaciones
    const errorValidacion = validationResult(req);
    if (!errorValidacion.isEmpty()) {
      const errores = errorValidacion.array();
      res.status(400).json(errores)
    } else {

      let sql = 'UPDATE service SET service_name = ?, service_description = ?, service_price = ?, service_is_deleted = ? WHERE service_id = ?';
      let values = [service_name, service_description, service_price, service_is_deleted, service_id];

      if (req.file) {
        values = [service_name, service_description, service_price, req.file.filename, service_is_deleted, service_id];
        sql = 'UPDATE service SET service_name = ?, service_description = ?, service_price = ?, service_image = ?, service_is_deleted = ? WHERE service_id = ?';
      }

      connection.query(sql, values, (err, result) => {
        if (err) {
          res.status(500).json(err)
        } else {
          res.status(200).json(result)
        }
      })
    }
  }


  delService = (req, res) => {
    const { service_id } = req.params;

    let sql = 'DELETE FROM service WHERE service_id = ?';

    connection.query(sql, service_id, (err, result) => {
      if (err) {
        res.status(500).json(err)
      } else {
        res.status(200).json("Servicio eliminado")
      }
    })
  }

  delBooking = (req, res) => {
    const { booking_id } = req.params;

    let sql = 'DELETE FROM booking WHERE booking_id = ?';

    connection.query(sql, booking_id, (err, result) => {
      if (err) {
        res.status(500).json(err)
      } else {
        res.status(200).json("Reserva eliminado")
      }

    })
  }

  getAllAdminParcels = (req, res) => {
    let sql = "SELECT * FROM parcel";

    connection.query(sql, (err, result) => {
      if (err) {
        return res
          .status(500)
          .json({ error: "Error al obtener las parcelas", details: err });
      } else {
        if (result.length > 0) {
          res.status(200).json({ parcels: result });
        } else {
          res.status(404).json("Error en la consulta");
        }
      }
    });
  };

  adminEditParcel = (req, res) => {
    const { parcel_name, area, parcel_price, parcel_available, parcel_id } = req.body;

    const errorValidacion = validationResult(req);
    if (!errorValidacion.isEmpty()) {
      const errores = errorValidacion.array();
      res.status(400).json(errores);
    } else {
      let sql =
        "UPDATE parcel SET parcel_name = ?, area = ?, parcel_price = ?, parcel_available = ? WHERE parcel_id = ?";

      let values = [
        parcel_name,
        area,
        parcel_price,
        parcel_available,
        parcel_id,
      ];

      connection.query(sql, values, (err, result) => {
        if (err) {
          res.status(500).json(err);
        } else {
          res.status(200).json(result);
        }
      });
    }
  };

  getParcelReserved = (req, res) => {
    let sql = `SELECT 
    p.parcel_name, 
    COUNT(b.booking_id) AS total_reservations
FROM 
    booking b
JOIN 
    parcel p ON b.parcel_id = p.parcel_id
GROUP BY 
    p.parcel_name
ORDER BY 
    total_reservations DESC
LIMIT 4;`

    connection.query(sql, (err, result) => {
      if(err){
        res.status(500).json(err)
      }else{
        res.status(200).json(result)
      }
    })
  }



  getServicesReserved = (req, res) => {
    let sql = `SELECT 
    s.service_name,
    COUNT(bs.service_id) AS total_contracted
FROM 
    booking_service bs
JOIN 
    service s ON bs.service_id = s.service_id
GROUP BY 
    s.service_name
ORDER BY 
    total_contracted DESC
LIMIT 4;`

    connection.query(sql, (err, result) => {
      if(err){
        res.status(500).json(err)
      }else{
        res.status(200).json(result)
      }
    })
  }

  getCityReserved = (req, res) => {
    let sql = `SELECT 
    u.city,
    COUNT(b.booking_id) AS total_reservations
FROM 
    booking b
JOIN 
    user u ON b.user_id = u.user_id
WHERE 
    u.city IS NOT NULL
GROUP BY 
    u.city
ORDER BY 
    total_reservations DESC
LIMIT 4`

    connection.query(sql, (err, result) => {
      if(err){
        res.status(500).json(err)
      }else{
        res.status(200).json(result)
      }
    })
  }

  getMonthReserved = (req, res) => {
    let sql = `SELECT 
    MONTHNAME(b.date_start) AS month_name,
    COUNT(b.booking_id) AS total_reservations
FROM 
    booking b
GROUP BY 
    month_name
ORDER BY 
    total_reservations DESC
LIMIT 4`

    connection.query(sql, (err, result) => {
      if(err){
        res.status(500).json(err)
      }else{
        res.status(200).json(result)
      }
    })
  }
}

export default new AdminController();