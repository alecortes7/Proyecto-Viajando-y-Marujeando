import connection from "../config/db.js";
import nodemailer from 'nodemailer'

class IndexController {
  constructor(){
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    })
  }

  home = (req, res) => {
    res.status(200).json("home")
  }

  getServices = (req, res) => {
    let sql = 'SELECT * FROM service WHERE service_is_deleted = 0';

    connection.query(sql, (err, result) => {
      if(err){
        res.status(500).json(err)
      }else{
        res.status(200).json(result)
      }
    })
  }

  sendContactFormEmail = (req, res) => {
    const {name, lastname, phone, email, comment} = req.body;
    console.log(req.body);
    

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: process.env.EMAIL_USER,
      subject: 'Nuevo contacto',
      html: `
        <h1>Nuevo mensaje de contacto</h1>
        <p><b>Nombre:</b> ${name} ${lastname}</p>
        <p><b>Teléfono:</b> ${phone}</p>
        <p><b>Email:</b> ${email}</p>
        <p><b>Comentario:</b> ${comment}</p>
        ` 
    };

    this.transporter.sendMail(mailOptions)
      .then(() => {
        res.status(200).json('Contacto enviado exitosamente')
      })
      .catch((err) => {
        res.status(500).json('Error al enviar el contacto')
      });
  };
}

export default new IndexController;