import connection from "../config/db.js";

class ParcelsController {
  getUserParcels = (req, res) => {
    res.status(200).json("user parcels")
  }
}

export default new ParcelsController;