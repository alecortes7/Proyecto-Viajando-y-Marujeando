import connection from "../config/db.js";

class ReservasController {
  getUserBooking = (req, res) => {
    const { user_id } = req.params;
    console.log(user_id)

    let sql = `SELECT 
      b.booking_id,
      b.date_start,
      b.date_end,
      b.booking_is_deleted,
      p.parcel_name,
      p.area,
      p.parcel_price,
      p.parcel_available,
      p.coordinates,
    GROUP_CONCAT(srv.service_name SEPARATOR ', ') AS service_names,
    GROUP_CONCAT(s.amount SEPARATOR ', ') AS service_amounts
    FROM 
      booking b
    JOIN 
      parcel p ON b.parcel_id = p.parcel_id
    LEFT JOIN 
      booking_service s ON b.booking_id = s.booking_id
    LEFT JOIN 
      service srv ON s.service_id = srv.service_id
    WHERE 
      b.user_id = ?
    AND b.booking_is_deleted = 0
    GROUP BY 
      b.booking_id;`;

    connection.query(sql, [user_id], (err, result) => {
      if (err) {
        res.status(500).json(err)
      } else {
        res.status(200).json(result)
      }
    })
  }


  getParcelasDisponibles = (req, res) => {
    const { formattedDateStart, formattedDateEnd } = req.body;
    
    // Consulta para obtener parcelas ocupadas en el rango de fechas
    const sql = `
    SELECT * 
    FROM parcel 
    WHERE parcel_id IN (
        SELECT parcel_id 
        FROM booking 
        WHERE date_start < ? AND date_end > ?
    ) 
    OR parcel_available = 0;`;

    connection.query(sql, [formattedDateEnd, formattedDateStart], (errOcupadas, resOcupadas) => {
      if (errOcupadas) {
          return res.status(500).json(errOcupadas);
      }
      
      const parcelasOcupadasIds = resOcupadas.map(p => p.parcel_id);

      // Consulta para obtener todas las parcelas
      const sqlTodas = `SELECT * FROM parcel;`;
      connection.query(sqlTodas, (errTodas, resTodas) => {
          if (errTodas) {
              return res.status(500).json(errTodas);
          }

          // Filtrar las parcelas libres
          const parcelasLibres = resTodas.filter(parcel => 
            !parcelasOcupadasIds.includes(parcel.parcel_id) && parcel.parcel_available === 1
          );
          // Filtrar las parcelas ocupadas
          const parcelasOcupadas = resOcupadas;

          res.status(200).json({
              parcelasLibres,
              parcelasOcupadas
          });
      });
    });
  };

  getServiceBooking = (req, res) => {
    let sql = 'SELECT * FROM service WHERE service_is_deleted = 0';

    connection.query(sql, (err, result) => {
      if(err){
        res.status(500).json(err)
      }else{
        res.status(200).json(result)
      }
    })
  }

  saveBooking = (req, res) => {
    const {user_id, parcel_id, date_start, date_end, services} = req.body;
    
    let sql = 'INSERT INTO booking (user_id, parcel_id, date_start, date_end) VALUES (?,?,?,?)';
    let values = [user_id, parcel_id, date_start, date_end];

    connection.query(sql, values, (err, result) => {
      if(err){
        return res.status(500).json(err);
      }

      const bookingId =  result.insertId;

      if (services && services.length > 0) {
        let sqlBokingServices = 'INSERT INTO booking_service (booking_id, service_id, amount) VALUES ';
        let valuesBokingServices = [];
  
        services.forEach(service => {
          sqlBokingServices += '(?, ?, ?),';
          valuesBokingServices.push(bookingId, service.datosServicio.service_id, service.cantidadServicio);
        })
  
        sqlBokingServices = sqlBokingServices.slice(0, -1);
  
        connection.query(sqlBokingServices, valuesBokingServices, (errBS, resBS)=>{
          if (errBS) {
            return res.status(500).json(errBS);
          }
          return res.status(200).json(resBS);
        }) 
      } else {
        return res.status(200).json(result);
      }

    })
  }
}

export default new ReservasController;