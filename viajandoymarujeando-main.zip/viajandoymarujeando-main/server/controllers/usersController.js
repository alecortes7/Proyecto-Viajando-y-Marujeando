import connection from "../config/db.js";
import bcrypt from 'bcrypt';
import { validationResult } from 'express-validator';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import nodemailer from 'nodemailer'
import crypto from 'crypto'

dotenv.config();

class UsersController {

  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });


  registerUser = (req, res) => {

    //Comprobar datos para validarlos
    const errorValidacion = validationResult(req);
    const { user_name, lastname, email, password, password2, phone, dni } = req.body;

    if (!errorValidacion.isEmpty()) {
      const errores = errorValidacion.array();
      res.status(400).json(errores)
    } else {
      //ver si el email existe en DB
      let sqlEmail = 'SELECT * FROM user where email = ?';

      connection.query(sqlEmail, [email], (errorEmail, resultEmail) => {
        if (errorEmail) {
          res.status(500).json(errorEmail);
        } else {
          if (resultEmail.length) {
            res.status(500).json("El email ya esta registrado")
          } else {
            //Encriptar contraseña y guardar en db
            bcrypt.hash(password, 8, (err, hash) => {
              if (err) {
                res.status(500).json(err);
              } else {
                let values = [user_name, lastname, email, hash, phone, dni]

                let sql = 'INSERT INTO user (user_name, lastname, email, password, phone, dni) VALUES (?, ?, ?, ?, ?, ?)';

                connection.query(sql, values, (errSql, result) => {
                  if (errSql) {
                    res.status(500).json(errSql);
                  } else {

                    const token = jwt.sign(
                      { user_id: result.insertId },
                      process.env.TOKEN_SECRET,
                      { expiresIn: '3d' }
                    );
                    this.sendConfirmationEmail(user_name, email, token)
                      .then(() => {
                        res.status(200).json("Usuario registrado correctamente.Mandado email de confirmación")
                      })
                      .catch((err) => {
                        res.status(500).json("Usuario registrado, pero ha habido un error al enviar el email de confirmación")
                      })
                  }
                })
              }
            })
          }
        }
      })
    }
  }

  sendConfirmationEmail = (user_name, email, token) => {
    const confirmationUrl = `http://localhost:5173/confirmRegister?token=${token}`;

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Confirma tu cuenta',
      html: `
        <h1>Hola, ${user_name}</h1>
        <p>Gracias por registrarte. Para confirmar tu cuenta haz clic en el siguiente enlace:</p>
        <a href='${confirmationUrl}'>Confirmar registro</a>
      `,
    };

    return this.transporter.sendMail(mailOptions)
  };

  confirmRegister = (req, res) => {
    const token = req.token;

    if (!token) {
      return res.status(400).json("Token no proporcionado");
    }


    const { user_id } = jwt.decode(token);



    // Actualizar el estado de la cuenta en la base de datos (activar cuenta)
    let sql = 'UPDATE user SET enabled_status = 2 WHERE user_id = ?';

    connection.query(sql, [user_id], (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.status(200).json("Cuenta confirmada");
      }
    });

  };

  login = (req, res) => {
    const { email, password } = req.body;

    //Comprobar si existe el email
    let sql = 'SELECT * FROM user where email = ? and enabled_status = 2';

    connection.query(sql, [email], (errEmail, resultEmail) => {
      if (errEmail) {
        res.status(500).json(errEmail);
      } else if (!resultEmail.length) {
        res.status(401).json("El email no existe o esta sin verificar")
      }
      else {
        //Comprobar contraseña
        bcrypt.compare(password, resultEmail[0].password, (errPass, response) => {
          if (errPass) {
            res.status(500).json(errPass)
          } else if (!response) {
            res.status(401).json("La contraseña es incorrecta")
          } else {
            //si las contraseñas coinciden, Genero un token y lo mando al front
            let token = jwt.sign({
              user_id: resultEmail[0].user_id,
            },
              process.env.TOKEN_SECRET,
              { expiresIn: "10d" }
            )
            res.status(200).json(token);
          }
        })
      }
    })
  }

  getOneUser = (req, res) => {
    //Extraigo el user_id del token
    const token = req.headers.authorization.split(" ")[1];
    let payload = jwt.decode(token);
    const { user_id } = payload;

    let sql = 'SELECT * FROM user WHERE user_id = ? AND enabled_status = 2';

    connection.query(sql, [user_id], (err, result) => {
      if (err) {
        res.status(500).json(err);
      } else {
        res.status(200).json(result[0])
      }
    })
  }


  editUser = (req, res) => {
    const { user_id } = req.params;
    
    const { user_name, lastname, phone, dni, address, province, city, country } = req.body;

    //Comprobar datos para validarlos
    const errorValidacion = validationResult(req);
    if (!errorValidacion.isEmpty()) {
      const errores = errorValidacion.array();
      res.status(400).json(errores)
    } else {
      
      let sql = 'UPDATE user SET user_name = ?, lastname = ?, phone = ?, dni = ?, address = ?, province = ?, city = ?, country = ? WHERE user_id = ?';
      let values = [user_name, lastname, phone, dni, address, province, city, country, user_id];

      if(req.file){
        values = [user_name, lastname, phone, dni, address, province, city, country, req.file.filename, user_id];
        sql = 'UPDATE user SET user_name = ?, lastname = ?, phone = ?, dni = ?, address = ?, province = ?, city = ?, country = ?, image = ? WHERE user_id = ?';
      }
  
      connection.query(sql, values, (err, result) => {
        if (err) {
          res.status(500).json(err)
        } else {
          res.status(200).json(result)
        }
      })
    }
  }


  generateRandomPassword = () => {
    return crypto.randomBytes(8).toString('hex');
  };

  resetPassword = (req, res) => {
    const {email} = req.body;

    let sqlEmail = 'SELECT * FROM user WHERE email = ?';
    connection.query(sqlEmail, [email], (error, result) => {
      if(error){
        res.status(500).json(error);
      }
      else if(!result.length){
        res.status(500).json("El email no existe");
      }
      else{
        //Generar nueva contraseña y hashearla
        const newPassword = this.generateRandomPassword();
        bcrypt.hash(newPassword, 8, (err, hash) => {
          if(err){
            res.status(500).json(err);
          }
          else{
            let sqlUpdate = 'UPDATE user SET password = ? WHERE email = ?';

            connection.query(sqlUpdate, [hash, email], (errUpdate, resultUpdate) => {
              if(errUpdate){
                res.status(500).json(errUpdate);
              }
              else{
                //Enviamos correo con la nueva contraseña
                const mailOptions = {
                  from: process.env.EMAIL_USER,
                  to: email,
                  subject: 'Contraseña restablecida',
                  html: `
                    <h1>Contraseña restablecida</h1>
                    <p>Tu nueva contraseña es: <b>${newPassword}</b></p>
                    <p>Cambie la contraseña después de iniciar sesión</p>
                  `
                };
                this.transporter.sendMail(mailOptions)
                  .then(()=>{
                    res.status(200).json('Contraseña restablecida y enviada por email')
                  })
                  .catch(errMail => {
                    res.status(500).json('Error al mandar email')
                  })
              }
            })
          }
        })
      }
    })
  }
}

export default new UsersController;