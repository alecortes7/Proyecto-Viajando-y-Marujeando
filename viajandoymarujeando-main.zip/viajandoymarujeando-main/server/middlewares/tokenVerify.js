import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();



export const tokenVerify = (req, res, next) =>{
    const tokenBearer = req.headers.authorization;
    
    if(!tokenBearer){
        res.status(401).json("No autorizado (no viene el token con la peticion)")
    } else {
        let token = tokenBearer.split(" ")[1];
        jwt.verify(token, process.env.TOKEN_SECRET, (err)=>{
            //si la palabra secreta del token no coincide o el token está caducado, te da un error
            if(err){
                res.status(401).json("No autorizado (Token no válido)")
            } else {
                req.token = token;
                next();
            }
        });        
    };
};