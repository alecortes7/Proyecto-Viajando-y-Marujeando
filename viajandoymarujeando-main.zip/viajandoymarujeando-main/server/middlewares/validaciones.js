import { body } from 'express-validator';
import connection from "../config/db.js";


const validaciones = [
    body('email')
    .isEmail()
    .withMessage('Debe proporcionar un correo válido')
    .custom((value) => {
      return new Promise((resolve, reject) => {
        const sql = 'SELECT * FROM user WHERE email = ?';
        connection.query(sql, [value], (err, result) => {
          if (err) {
            console.error(err);
            return reject(new Error('Error al verificar el correo: ' + err.message));
          }
          if (result.length) {
            return reject(new Error('Este correo ya está registrado'));
          }
          resolve(true); 
        });
      });
    }),
  body('password')
    .isLength({ min: 6 })
    .withMessage('La contraseña debe tener al menos 6 caracteres'),
  body('password2')
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('Las contraseñas no coinciden.');
      }
      return true;
    })
    .withMessage('Las contraseñas no coinciden.'),
  body('user_name')
    .isLength({min:4})
    .withMessage('El nombre debe tener minimo 4 caracteres'),
    body('lastname')
    .notEmpty()
    .withMessage('El apellido es obligatorio'),
    body('phone')
    .notEmpty()
    .withMessage('El teléfono es obligatorio'),
    body('dni')
    .isLength({min:9, max: 20})
    .withMessage('El dni debe tener minimo 9 caracteres y un maximo de 20') 
];


export const validacionesEdit = 
[
  body('user_name')
    .isLength({min:4})
    .withMessage('El nombre debe tener minimo 4 caracteres'),
    body('lastname')
    .notEmpty()
    .withMessage('El apellido es obligatorio'),
    body('phone')
    .notEmpty()
    .withMessage('El teléfono es obligatorio'),
    body('dni')
    .isLength({min:9})
    .withMessage('El dni debe tener minimo 9 caracteres')
];

export const validacionesAddService = [
  body('service_name')
    .isLength({min:4})
    .withMessage('El nombre debe tener minimo 4 caracteres'),
    body('service_description')
    .notEmpty()
    .withMessage('La descripción no puede estar vacia'),
    body('service_price')
    .notEmpty()
    .withMessage('Debes introducir un precio')
];

export const validacionesEditParcel = [
  body('parcel_name')
    .isLength({min:2})
    .withMessage('El nombre debe tener minimo 2 caracteres'),
    body('area')
    .notEmpty()
    .withMessage('El area no puede estar vacia'),
    body('parcel_price')
    .notEmpty()
    .withMessage('Debes introducir un precio'),
    body('parcel_available')
    .notEmpty()
    .withMessage('Debes introducir un ')
];

export default validaciones;

