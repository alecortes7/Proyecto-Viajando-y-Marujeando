import express from 'express';
import adminController from '../controllers/adminController.js';
import {tokenVerify} from '../middlewares/tokenVerify.js'
import uploadImage from './../middlewares/multerSingle.js';
import { validacionesAddService, validacionesEditParcel } from '../middlewares/validaciones.js';
import { editParser } from '../middlewares/dataParser.js';

const router = express.Router();

/* GET users listing. */
router.get('/', adminController.admin);

router.get('/adminAllUsers', tokenVerify, adminController.getAllUsers)

router.put('/deshabilitarUser/:user_id',tokenVerify, adminController.deshabilitarUser)

router.put('/habilitarUser/:user_id',tokenVerify, adminController.habilitarUser)
router.post('/addService', uploadImage("services"), tokenVerify, editParser, validacionesAddService, adminController.addService)

router.get('/getAllServices', tokenVerify, adminController.getAllServices);
router.put('/editService/', uploadImage("services"), tokenVerify, editParser, validacionesAddService, adminController.editService);
router.get('/delService/:service_id',  tokenVerify,  adminController.delService);
router.get('/delBooking/:booking_id',  tokenVerify,  adminController.delBooking);

router.get('/adminBooking', tokenVerify, adminController.getAdminBookings);

router.get("/allAdminParcels", adminController.getAllAdminParcels)

router.put("/adminEditParcel", tokenVerify, validacionesEditParcel, adminController.adminEditParcel)
router.get("/getParcelReserved", tokenVerify,  adminController.getParcelReserved)
router.get("/getServicesReserved", tokenVerify,  adminController.getServicesReserved)
router.get("/getCityReserved", tokenVerify,  adminController.getCityReserved)
router.get("/getMonthReserved", tokenVerify,  adminController.getMonthReserved)

export default router;