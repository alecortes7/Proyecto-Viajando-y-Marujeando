import express from 'express';
import indexController from '../controllers/indexController.js';
const router = express.Router();


router.get('/', indexController.home);
router.get('/getServices', indexController.getServices);

router.post('/sendContact', indexController.sendContactFormEmail);

export default router;
