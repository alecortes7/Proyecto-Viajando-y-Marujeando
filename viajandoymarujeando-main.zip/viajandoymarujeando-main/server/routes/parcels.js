import express from "express";
import parcelsController from "../controllers/parcelsController.js";
import { tokenVerify } from "../middlewares/tokenVerify.js";
const router = express.Router();

router.get(
  "/getUserParcels/:parcel_id",
  tokenVerify,
  parcelsController.getUserParcels
);

export default router;
