import express from 'express';
import reservasController from '../controllers/reservasController.js';

const router = express.Router();

router.get('/getUserBooking/:user_id',reservasController.getUserBooking);
// Ruta para obtener parcelas libres y ocupadas
router.post('/dispParcel', reservasController.getParcelasDisponibles);

router.get('/getServices',reservasController.getServiceBooking);

//Ruta para insertar datos de la reserva en db
router.post('/saveBooking', reservasController.saveBooking)

export default router;