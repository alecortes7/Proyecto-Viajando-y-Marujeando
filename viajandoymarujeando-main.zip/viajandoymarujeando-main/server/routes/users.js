import express from 'express';
import usersController from '../controllers/usersController.js';
import validaciones, { validacionesEdit }  from '../middlewares/validaciones.js';
import { tokenVerify } from '../middlewares/tokenVerify.js';
import uploadImage from './../middlewares/multerSingle.js';
import { editParser } from '../middlewares/dataParser.js';
const router = express.Router();


router.post('/registerUser', validaciones, usersController.registerUser);
router.post('/confirmRegister', usersController.sendConfirmationEmail);
router.put('/confirmRegister', tokenVerify, usersController.confirmRegister);
router.put('/editUser/:user_id', uploadImage("users"), tokenVerify, editParser, validacionesEdit,  usersController.editUser);
router.post('/login', usersController.login);
router.get('/getOneUser', tokenVerify, usersController.getOneUser);
router.post('/resetPassword', usersController.resetPassword);

export default router;
